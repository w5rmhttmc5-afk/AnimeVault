import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const results = [];
const check = (name, fn) => {
  try { fn(); results.push({ name, ok: true }); }
  catch (error) { results.push({ name, ok: false, detail: error?.message || String(error) }); }
};
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');
const exists = (file) => { if (!fs.existsSync(path.join(root, file))) throw new Error(`Datei fehlt: ${file}`); };
const includes = (file, text, label = text) => { if (!read(file).includes(text)) throw new Error(`Nicht gefunden in ${file}: ${label}`); };

check('Projektdateien vorhanden', () => {
  for (const file of ['package.json','index.html','src/App.jsx','src/main.jsx','src/styles.css','start.bat','verify.bat','manifest.webmanifest','sw.js','SUPABASE-CLOUD-SYNC.sql']) exists(file);
});
check('package.json ist gültiges JSON und hat Build-Scripts', () => {
  const p = JSON.parse(read('package.json'));
  if (!p.scripts?.build || !p.scripts?.dev || !p.scripts?.check) throw new Error('dev/build/check Script fehlt');
  for (const dep of ['react','react-dom','lucide-react']) if (!p.dependencies?.[dep]) throw new Error(`Abhängigkeit fehlt: ${dep}`);
  if (!p.devDependencies?.vite) throw new Error('Vite fehlt');
});
check('Manifest ist gültiges JSON', () => {
  const m = JSON.parse(read('manifest.webmanifest'));
  if (!m.name || !Array.isArray(m.icons) || !m.icons.length) throw new Error('Manifestname oder Icons fehlen');
});
check('Navigation enthält die wichtigsten Bereiche', () => {
  const s = read('src/App.jsx');
  for (const label of ['Startseite','Entdecken','Swipe-Modus','Meine Liste','Release Radar','Franchise','Profil & Erfolge','Community','Statistiken']) if (!s.includes(label)) throw new Error(`Navigation fehlt: ${label}`);
});
check('Erweiterte Suche und Filter sind verdrahtet', () => {
  const s = read('src/App.jsx');
  for (const marker of ['minYear','maxYear','minScore','maxEpisodes','sortBy','Filter zurücksetzen']) if (!s.includes(marker)) throw new Error(`Suchfunktion fehlt: ${marker}`);
});
check('Personalisierung, Likes und Bewertungen sind vorhanden', () => {
  const s = read('src/App.jsx');
  for (const marker of ['tasteGenres','likedIds','dislikedIds','ratings','swipeAction','undoSwipe']) if (!s.includes(marker)) throw new Error(`Personalisierung fehlt: ${marker}`);
});
check('Statistiken und geschätzte Watchtime sind vorhanden', () => {
  const s = read('src/App.jsx');
  for (const marker of ['Geschätzte Watchtime','Genre-Vorlieben','24),0)/60','progress-panel']) if (!s.includes(marker)) throw new Error(`Statistik fehlt: ${marker}`);
});
check('Profil, Community und Listen-Export sind vorhanden', () => {
  const s = read('src/App.jsx');
  for (const marker of ['friendProfiles','exportProfileLink','createCustomList','exportWatchlist','importWatchlist']) if (!s.includes(marker)) throw new Error(`Profil/Community-Funktion fehlt: ${marker}`);
});
check('Cloud-Sync hat Login, Upload und Restore', () => {
  const s = read('src/App.jsx');
  for (const marker of ['cloudAuth','cloudSync','Cloud hochladen','Cloud wiederherstellen','animevault_sync']) if (!s.includes(marker)) throw new Error(`Cloud-Funktion fehlt: ${marker}`);
});
check('Cloud-SQL aktiviert Row Level Security und User-Abgrenzung', () => {
  const s = read('SUPABASE-CLOUD-SYNC.sql');
  if (!/enable row level security/i.test(s) || !/auth\.uid\(\)\s*=\s*user_id/i.test(s)) throw new Error('RLS oder Auth-User-Prüfung fehlt');
  const executableSql = s.split('\n').filter(line => !line.trim().startsWith('--')).join('\n');
  if (/service_role/i.test(executableSql)) throw new Error('SQL sollte keinen service_role-Key benötigen');
});
check('PWA und Service Worker sind eingerichtet', () => {
  includes('index.html', 'manifest.webmanifest');
  includes('src/main.jsx', 'navigator.serviceWorker.register');
  includes('src/main.jsx', 'import.meta.env.PROD');
  includes('sw.js', 'addEventListener');
});
check('Start- und Prüfskript enthalten Fehlerbehandlung', () => {
  includes('start.bat', 'npm install');
  includes('verify.bat', 'npm run build');
  includes('verify.bat', 'animevault-testbericht.txt');
});

const passed = results.filter(x => x.ok).length;
const failed = results.length - passed;
const report = [
  'ANIMEVAULT – AUTOMATISCHER PROJEKTCHECK',
  `Datum: ${new Date().toLocaleString('de-DE')}`,
  `Ergebnis: ${passed}/${results.length} Checks bestanden`,
  '',
  ...results.map((r, i) => `${r.ok ? 'PASS' : 'FAIL'} ${String(i + 1).padStart(2, '0')} – ${r.name}${r.detail ? `\n     ${r.detail}` : ''}`),
  '',
  'Hinweis: Diese Checks prüfen Projektstruktur und erwartete Feature-Hooks. Sie ersetzen keinen erfolgreichen Vite-Build und keinen manuellen Browser-/Cloud-Test.'
].join('\n');
fs.writeFileSync(path.join(root, 'animevault-testbericht.txt'), report + '\n', 'utf8');
console.log(report);
if (failed) process.exitCode = 1;
