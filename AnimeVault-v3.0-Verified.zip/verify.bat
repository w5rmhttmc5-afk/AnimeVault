@echo off
cd /d "%~dp0"
title AnimeVault - Vollstaendige Pruefung
set LOG=animevault-testbericht.txt

echo ================================================
echo AnimeVault - automatische Pruefung
echo ================================================
echo.

echo [1/3] Pruefe installierte Abhaengigkeiten...
call npm ls --depth=0 >nul 2>&1
if errorlevel 1 (
  echo Installiere bzw. repariere Abhaengigkeiten. Das braucht Internet und kann dauern...
  call npm install --no-audit --no-fund
  if errorlevel 1 goto install_error
) else (
  echo Abhaengigkeiten sind vorhanden.
)

echo.
echo [2/3] Pruefe Dateien und Feature-Hooks...
call npm run check
if errorlevel 1 goto check_error

echo.
echo [3/3] Baue die echte Produktionsversion...
call npm run build > build-output.txt 2>&1
if errorlevel 1 goto build_error

echo.
echo ERFOLG: Der Produktions-Build ist durchgelaufen.
echo Build-Details stehen in build-output.txt.
echo Feature-Checks stehen in animevault-testbericht.txt.
echo.
echo Jetzt kannst du den Ordner dist fuer das Hosting verwenden.
echo.
pause
exit /b 0

:install_error
echo FEHLER: npm install ist fehlgeschlagen. Pruefe Internet und Node.js.
echo Versuche spaeter erneut, wenn die Verbindung stabil ist.
echo.
pause
exit /b 1

:check_error
echo FEHLER: Mindestens ein Projektcheck ist fehlgeschlagen.
echo Details: animevault-testbericht.txt
echo.
pause
exit /b 1

:build_error
echo FEHLER: Vite konnte den Produktions-Build nicht abschliessen.
echo Kopiere bitte build-output.txt und animevault-testbericht.txt und sende sie mir.
echo.
pause
exit /b 1
