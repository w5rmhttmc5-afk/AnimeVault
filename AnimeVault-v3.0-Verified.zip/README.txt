ANIMEVAULT – STARTANLEITUNG

1. ZIP-Datei entpacken.
2. Node.js LTS installieren, falls noch nicht installiert: https://nodejs.org/
3. start.bat doppelklicken.
4. Beim ersten Start werden Abhängigkeiten installiert. Danach startet Vite und öffnet die lokale Website.

NEU IN DIESER VERSION
- Entdecken nutzt AniList als Hauptquelle und lädt 50 Ergebnisse pro Seite; durch „Mehr Anime laden“ kannst du weit über 500 und in vielen Seiten auch mehrere tausend Titel durchsuchen. Es werden nicht alle auf einmal geladen, damit die Website schnell bleibt.
- Die Startseite zeigt 24 Live-Trends; die Pfeile blättern durch die Auswahl, statt alle gleichzeitig auf die Seite zu packen.
- Cover für den lokalen Katalog werden automatisch in kleinen ID-Gruppen gesucht und im Browser gespeichert. Sie sollten erscheinen, ohne dass du jeden Anime erst anklicken musst.
- Coverbilder werden über AniList nachgeladen und im Browser zwischengespeichert.
- Wenn Jikan nicht erreichbar ist, kann AnimeVault für Suche, beliebte Anime und weitere Seiten auf AniList zurückgreifen.
- Bei Anime-Details gibt es Suchlinks zu JustWatch Deutschland, Crunchyroll, Netflix, Prime Video und Disney+.
- Streaminglinks sind Suchseiten, keine Garantie, dass der Anime in Deutschland bei dem Dienst verfügbar ist. Verfügbarkeit und Abos können sich ändern.
- Die eigene Liste bleibt im localStorage des Browsers gespeichert.

WICHTIG
- Für neue Cover und Live-Ergebnisse wird Internet benötigt.
- Die App läuft lokal auf deinem PC. Das Terminalfenster muss geöffnet bleiben.
- Die Website streamt keine Anime und stellt keine Folgen bereit; sie zeigt Metadaten und verweist auf legale Plattform-Suchen.


UPDATE: GROSSER KATALOG, AUTO-COVER, TRENDS & SYNCHRO-HINWEISE
- Der Offline-Katalog wurde um viele weitere Serien und Filme erweitert. Live-Suche und Top-Listen können zusätzlich weitere tausende Titel aus öffentlichen Anime-Datenbanken laden.
- Aktuelle Trends werden online von AniList abgerufen und bis zu sechs Stunden zwischengespeichert. Beim Öffnen der Website wird bei abgelaufenem Cache erneut geladen. Die Seite muss dazu geöffnet sein und eine Internetverbindung haben; ein komplett ausgeschalteter PC führt keine Hintergrundupdates aus.
- In Anime-Details gibt es nun einen Synchronisationsbereich. Bei ausgewählten bekannten Titeln wird eine deutsche Synchro als bekannt markiert. Für andere Titel wird der Status bewusst als ungeprüft gezeigt und es gibt aktuelle Suchlinks. Die öffentlichen Anime-APIs liefern keine vollständigen verlässlichen Audio-Sprachen für jede Staffel/Region.
- Streaming-Links sind Suchlinks; Verfügbarkeit hängt von Land, Staffel und Abo ab.

SO STELLST DU ANIMEVAULT ONLINE
1. Entpacke die ZIP-Datei und installiere Node.js (LTS), falls noch nicht vorhanden.
2. Öffne den Ordner und starte start.bat. Beim ersten Start werden Pakete aus dem Internet installiert.
3. Für eine öffentliche Website: Lade den Projektordner in ein GitHub-Repository und importiere das Repository bei Netlify. Die netlify.toml ist bereits enthalten; Build-Befehl: npm run build, Veröffentlichungsordner: dist.
4. Die Website kann Trends beim Öffnen selbst aktualisieren. Solange niemand die Seite öffnet, läuft bei einer rein statischen Website kein Code im Hintergrund. Für fest geplante Updates auch bei geschlossenem Browser braucht man zusätzlich einen Server oder einen geplanten Cloud-Job (Cron).

WICHTIG: Synchronisations- und Streamingangaben sind teilweise Suchhinweise, keine offizielle vollständige Sprachen-Datenbank. Prüfe bei der jeweiligen Staffel und beim Anbieter, ob Deutsch tatsächlich verfügbar ist.

UPDATE v1.3 – AUTO-COVER, MEHR TRENDS, FRANCHISES & BACKUP
- Cover-Fallback: Karten, gespeicherte Anime und Details suchen fehlende Cover automatisch anhand des Titels nach. Du musst einen Anime nicht mehr anklicken, damit ein fehlendes Bild gesucht wird. Das braucht Internet; nicht jeder seltene/alternative Titel lässt sich eindeutig zuordnen.
- Live-Trends: bis zu 50 Trendtitel von AniList. Auf der Startseite bleibt die Anzeige übersichtlich: fünf Karten gleichzeitig, mit Pfeilen durch die Trend-Auswahl blättern.
- Laufende Serien: eine zusätzliche Reihe zeigt Anime aus den Trenddaten, die als laufend markiert sind. Wenn AniList einen nächsten Sendetermin liefert, wird er bei der Karte angezeigt.
- Synchronisationsfilter: unter Entdecken gibt es „Deutsche Synchro bekannt“. Das ist eine kuratierte Orientierung für bekannte Titel und keine vollständige oder offiziell bestätigte Dub-Datenbank.
- Reihenfolge: Anime-Details können Vorgänger, Fortsetzungen und weitere verbundene Einträge aus AniList anzeigen. Auf einen Eintrag klicken, um seine Details zu öffnen.
- Watchlist-Backup: Einstellungen → Backup exportieren erstellt eine JSON-Datei. Backup importieren führt die gespeicherten Einträge mit deiner vorhandenen Liste zusammen.
- Großer Katalog: Entdecken lädt 50 Titel pro Seite und kann über viele Seiten mehrere tausend Anime durchsuchen. Die öffentliche AniList-API begrenzt die erreichbare Seitentiefe; die ganze Datenbank wird nicht auf einmal geladen.
- Automatische Cover-Suche und Live-Trends benötigen eine Internetverbindung. Cover und Trends werden im Browser zwischengespeichert, damit wiederholte Aufrufe weniger Anfragen brauchen.


UPDATE v2.0 – SMARTER SWIPE, PROFIL, COMMUNITY & PWA
- Smarter Algorithmus: Likes, übersprungene Titel, Watchlist-Status, abgeschlossene Anime und eigene Bewertungen beeinflussen Genre-Empfehlungen. Daten werden lokal gespeichert.
- Swipe 2.0: Herz fügt ohne Popup zur Liste hinzu; X überspringt; Undo macht den letzten Swipe rückgängig. Likes und übersprungene Titel erscheinen gesammelt.
- Animationen: sanfte Seitenwechsel, Karten-Hover, leuchtende Hintergründe und animierte Swipe-Karten. Bewegungen werden bei „Bewegung reduzieren“ im Betriebssystem minimiert.
- Profil: anpassbarer Anzeigename, XP/Level, Achievements, Statistiken und Jahresrückblick. Abgeschlossene Titel werden ab Version 2.0 mit Datum markiert.
- Release Radar: zeigt von AniList gemeldete nächste Folgen mit Countdown. Wenn keine konkreten Sendetermine vorliegen, werden diese nicht erfunden.
- Franchise Guide: kuratierte Watch-Orders mit Filmen und Specials; Reihenfolge kann je nach bevorzugter Kontinuität variieren.
- Community: eigene thematische Listen, Bewertungen, JSON-Export der Listen und teilbare Profil-Recaps über einen Link. Es gibt keinen Server-Account oder automatische Cloud-Synchronisierung; lokale Listen bleiben auf diesem Gerät.
- PWA: manifest, App-Icons und Service Worker für installierbare App-Oberfläche und Offline-Grundfunktionen. Live-Katalog, externe Poster und aktuelle Termine benötigen weiterhin Internet. Installieren über das Browser-Menü im veröffentlichten Build (HTTPS). Im Entwicklungsmodus via start.bat ist der Service Worker absichtlich deaktiviert.

TESTHINWEIS
- JSX/JavaScript wurde mit dem installierten TypeScript-Parser auf Syntax geprüft; Manifest-JSON und Archiv werden separat validiert. Ein Vite-Produktions-Build konnte in dieser Umgebung nicht ausgeführt werden, weil npm beim Herunterladen der Abhängigkeiten in einen Timeout lief. Beim ersten Start muss npm install mit Internetzugang erfolgreich sein.
- Swipe-Nachschub: Wenn nur noch wenige Vorschläge übrig sind, lädt der Swipe-Modus automatisch weitere AniList-Seiten nach, solange die Datenquelle mehr Ergebnisse meldet.


UPDATE v3.0 – CINEMATIC DESIGN, SMART DISCOVERY, STATS, FRIENDS & CLOUD SYNC
- Cinematic UI: verbesserte Übergänge, dezente animierte Hintergrundlichter, Poster-Hover und einheitliche Bewegungen. Systemeinstellung „Bewegung reduzieren“ wird respektiert.
- Persönliche Empfehlungen: Startseite zeigt „Für dich empfohlen“ anhand von Genre-Vorlieben, Bewertungen, Likes, Trends und deiner Sammlung. Swipe-Empfehlungen nutzen denselben Geschmacksscore.
- Erweiterte Suche: Filter für Jahr von/bis, Mindest-Score und maximale Episodenzahl; Sortierung nach Beliebtheit/Score, Neuheit, Titel oder Episodenzahl.
- Statistiken: Genre-Vorlieben, Bewertungsanzahl, Likes, Sammlung nach Status und geschätzte Watchtime. Watchtime rechnet mit ca. 24 Minuten je Folge; das ist ein Richtwert, keine gemessene Wiedergabezeit.
- Anime-Freunde: Profil-Snapshots können per Profil-Link ausgetauscht und im Profil gespeichert werden. Es werden nur die im Link enthaltenen Zahlen/Favoriten geteilt, nicht die komplette private Watchlist.
- Cloud-Synchronisierung: optional über ein eigenes Supabase-Projekt mit E-Mail-Konto. In Einstellungen Project URL und den öffentlichen anon/publishable Key eintragen, das SQL aus SUPABASE-CLOUD-SYNC.sql einmalig im Supabase SQL Editor ausführen, Konto erstellen/anmelden und manuell „Cloud hochladen“ bzw. „Cloud wiederherstellen“ wählen. Verwende niemals den service_role-Key im Browser. Die Tabelle schützt Datensätze per Row Level Security und Auth-User-ID.
- Cloud-Sync ist optional und benötigt Internet sowie ein selbst eingerichtetes Supabase-Projekt. Ohne Cloud-Einrichtung bleiben alle bisherigen lokalen Funktionen erhalten. Wenn die E-Mail-Bestätigung in Supabase aktiv ist, muss das Konto zuerst bestätigt werden.

TESTSTATUS v3.0
- App.jsx und main.jsx durch TypeScript-Transpiler auf JSX/JavaScript-Syntax geprüft; sw.js, package.json und manifest.webmanifest separat geprüft.
- npm install wurde in der Entwicklungsumgebung erneut durch ein Zeitlimit unterbrochen. Deshalb konnte kein vollständiger Vite-Produktions-Build und kein Browser-End-to-End-Test durchgeführt werden. Nach Entpacken bitte start.bat starten; bei Fehlern die Terminalmeldung sichern.


UPDATE – PRÜFUNG UND FEHLERSUCHE
- Neue Datei verify.bat: Doppelklick, um Abhängigkeiten zu prüfen/reparieren, die automatischen Projektchecks auszuführen und einen echten Vite-Produktions-Build zu versuchen.
- npm run check prüft die erwarteten Projektdateien, Hauptbereiche, Suchfilter, Personalisierung, Statistiken, Community-Funktionen, Cloud-Endpunkte, SQL-Sicherheitsregeln und PWA-Einrichtung.
- animevault-testbericht.txt zeigt das Ergebnis der statischen Checks. build-output.txt enthält bei einem fehlgeschlagenen Produktions-Build die eigentliche Fehlermeldung.
- Wichtig: Statische Checks bestätigen, dass zentrale Dateien und Feature-Hooks vorhanden sind. Sie beweisen nicht, dass jede Interaktion im Browser funktioniert. Dafür ist der Produktions-Build plus ein kurzer manueller Test nötig.
- Falls verify.bat fehlschlägt, sende animevault-testbericht.txt und build-output.txt. Teile niemals dein Supabase-Passwort oder private Schlüssel.
