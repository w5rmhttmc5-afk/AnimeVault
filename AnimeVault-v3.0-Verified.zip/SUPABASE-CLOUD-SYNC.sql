-- AnimeVault v3.0 cloud sync table
-- Run this once in your own Supabase project's SQL Editor.
-- Never put a service_role key into the browser. Use the public anon/publishable key.
create table if not exists public.animevault_sync (
  user_id uuid primary key references auth.users(id) on delete cascade,
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.animevault_sync enable row level security;

drop policy if exists "Users can read their own AnimeVault sync" on public.animevault_sync;
create policy "Users can read their own AnimeVault sync"
  on public.animevault_sync for select to authenticated
  using (auth.uid() = user_id);

drop policy if exists "Users can insert their own AnimeVault sync" on public.animevault_sync;
create policy "Users can insert their own AnimeVault sync"
  on public.animevault_sync for insert to authenticated
  with check (auth.uid() = user_id);

drop policy if exists "Users can update their own AnimeVault sync" on public.animevault_sync;
create policy "Users can update their own AnimeVault sync"
  on public.animevault_sync for update to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

grant select, insert, update on public.animevault_sync to authenticated;
