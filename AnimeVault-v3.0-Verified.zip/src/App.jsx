import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Search, Compass, Bookmark, BarChart3, Settings, Sparkles, Star, Play, Check, Plus, X, Heart, Clock3, Flame, SlidersHorizontal, ExternalLink, Download, Upload, CalendarDays, Undo2, Trophy, Users, Share2, ListChecks, GitBranch, Timer, Smartphone } from 'lucide-react';

const API = 'https://api.jikan.moe/v4';
const ANILIST_API = 'https://graphql.anilist.co';
async function aniListRequest(query, variables = {}) {
  const response = await fetch(ANILIST_API, {
    method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
    body: JSON.stringify({ query, variables }),
    signal: AbortSignal.timeout(9000),
  });
  if (!response.ok) throw new Error(`AniList ${response.status}`);
  const payload = await response.json();
  if (payload.errors?.length) throw new Error('AniList-Anfrage fehlgeschlagen');
  return payload.data;
}
const coverLookupPromises = new Map();
const normalizeTitleKey = value => String(value || '').toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]/g, '');
async function lookupAnimeCover(title, malId) {
  const titleKey = normalizeTitleKey(title);
  if (!titleKey) return '';
  try {
    const cached = JSON.parse(localStorage.getItem('animevault-poster-cache') || '{}');
    const cachedCover = (malId && cached[malId]) || cached[`title:${titleKey}`];
    if (cachedCover && !String(cachedCover).startsWith('data:image/svg+xml')) return cachedCover;
  } catch {}
  if (coverLookupPromises.has(titleKey)) return coverLookupPromises.get(titleKey);
  const request = (async () => {
    try {
      const data = await aniListRequest(`query ($search: String) { Media(search: $search, type: ANIME, isAdult: false) { id idMal title { romaji english } coverImage { large extraLarge } } }`, { search: title });
      const item = data.Media;
      const cover = item?.coverImage?.extraLarge || item?.coverImage?.large;
      const foundKeys = [item?.title?.english, item?.title?.romaji].map(normalizeTitleKey).filter(Boolean);
      const titleMatches = foundKeys.some(key => key === titleKey || (Math.min(key.length, titleKey.length) >= 6 && (key.includes(titleKey) || titleKey.includes(key))));
      if (!cover || !titleMatches) return '';
      try {
        const cache = JSON.parse(localStorage.getItem('animevault-poster-cache') || '{}');
        cache[`title:${titleKey}`] = cover;
        if (malId && malId > 0) cache[malId] = cover;
        localStorage.setItem('animevault-poster-cache', JSON.stringify(cache));
      } catch {}
      return cover;
    } catch { return ''; }
  })();
  coverLookupPromises.set(titleKey, request);
  const result = await request;
  if (!result) coverLookupPromises.delete(titleKey);
  return result;
}
function AnimeImage({ anime, className, alt = '', loading = 'lazy', style }) {
  const initial = anime?.images?.jpg?.large_image_url || anime?.images?.jpg?.image_url || posterPlaceholder(anime?.title || 'Anime');
  const [src, setSrc] = useState(initial);
  useEffect(() => {
    let cancelled = false;
    const current = anime?.images?.jpg?.large_image_url || anime?.images?.jpg?.image_url || '';
    if (current && !current.startsWith('data:image/svg+xml')) { setSrc(current); return () => { cancelled = true; }; }
    setSrc(posterPlaceholder(anime?.title || 'Anime'));
    lookupAnimeCover(anime?.title_english || anime?.title, anime?.mal_id).then(cover => { if (!cancelled && cover) setSrc(cover); });
    return () => { cancelled = true; };
  }, [anime?.mal_id, anime?.title, anime?.title_english, anime?.images?.jpg?.large_image_url, anime?.images?.jpg?.image_url]);
  return <img className={className} src={src} alt={alt || anime?.title || ''} loading={loading} style={style} onError={e => { if (!e.currentTarget.src.startsWith('data:image/svg+xml')) { e.currentTarget.onerror = null; setSrc(posterPlaceholder(anime?.title || 'Anime')); } }} />;
}

function normalizeAniList(item) {
  const title = item.title?.romaji || item.title?.english || 'Unbekannter Anime';
  const english = item.title?.english || item.title?.romaji || title;
  const cover = item.coverImage?.extraLarge || item.coverImage?.large || item.coverImage?.medium;
  return {
    mal_id: item.idMal || -item.id, anilist_id: item.id, title, title_english: english,
    score: item.averageScore ? Math.round(item.averageScore) / 10 : null, episodes: item.episodes ?? null,
    year: item.startDate?.year || null, genres: (item.genres || []).map(name => ({ name })), status: item.status || null, nextAiringEpisode: item.nextAiringEpisode || null, anilist_id: item.id,
    synopsis: (item.description || '').replace(/<[^>]*>/g, ' ').replace(/&#039;/g, "'").replace(/&quot;/g, '"').slice(0, 600),
    images: { jpg: { image_url: cover, large_image_url: cover } },
    source: 'AniList',
  };
}
const ANILIST_PAGE_QUERY = `query ($page: Int, $search: String) { Page(page: $page, perPage: 50) { pageInfo { hasNextPage } media(type: ANIME, search: $search, sort: POPULARITY_DESC, isAdult: false) { id idMal title { romaji english } coverImage { medium large extraLarge } episodes averageScore genres description startDate { year } } } }`;
const ANILIST_TRENDING_QUERY = `query { Page(page: 1, perPage: 50) { media(type: ANIME, sort: TRENDING_DESC, isAdult: false) { id idMal title { romaji english } coverImage { medium large extraLarge } episodes averageScore genres description startDate { year } status nextAiringEpisode { airingAt episode } } } }`;
async function fetchAniListTrending() {
  const data = await aniListRequest(ANILIST_TRENDING_QUERY);
  return (data.Page.media || []).map(normalizeAniList);
}
async function fetchAniListPage(page = 1, search = '') {
  const data = await aniListRequest(ANILIST_PAGE_QUERY, { page, search: search || null });
  return { data: (data.Page.media || []).map(normalizeAniList), hasNextPage: Boolean(data.Page.pageInfo?.hasNextPage) };
}

// Jikan limits request frequency. Retry temporary rate-limit/server errors and
// time out requests so the UI can never stay in a loading state forever.
async function apiGet(url) {
  let lastError;
  for (let attempt = 0; attempt < 2; attempt++) {
    if (attempt > 0) await new Promise(resolve => setTimeout(resolve, 900 * attempt));
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 6500);
    try {
      const response = await fetch(url, { signal: controller.signal });
      if (response.status === 429 || response.status >= 500) {
        lastError = new Error(`API ${response.status}`);
        continue;
      }
      if (!response.ok) throw new Error(`API ${response.status}`);
      return await response.json();
    } catch (error) {
      lastError = error;
    } finally {
      clearTimeout(timeout);
    }
  }
  throw lastError || new Error('API nicht erreichbar');
}
const starter = [
  { mal_id: 5114, title: 'Fullmetal Alchemist: Brotherhood', title_english: 'Fullmetal Alchemist: Brotherhood', score: 9.1, episodes: 64, year: 2009, genres: [{name:'Action'},{name:'Adventure'},{name:'Fantasy'}], images:{jpg:{large_image_url:'https://cdn.myanimelist.net/images/anime/1208/94745l.jpg'}}, synopsis:'Zwei Brüder suchen nach dem Stein der Weisen, um ihre verlorenen Körperteile zurückzubekommen.' },
  { mal_id: 16498, title: 'Shingeki no Kyojin', title_english: 'Attack on Titan', score: 8.5, episodes: 25, year: 2013, genres:[{name:'Action'},{name:'Drama'}], images:{jpg:{large_image_url:'https://cdn.myanimelist.net/images/anime/10/47347l.jpg'}}, synopsis:'Die Menschheit kämpft hinter gewaltigen Mauern ums Überleben.' },
  { mal_id: 38000, title: 'Kimetsu no Yaiba', title_english: 'Demon Slayer', score: 8.4, episodes: 26, year: 2019, genres:[{name:'Action'},{name:'Fantasy'}], images:{jpg:{large_image_url:'https://cdn.myanimelist.net/images/anime/1286/99889l.jpg'}}, synopsis:'Tanjiro wird Dämonenjäger, um seine Schwester zu retten.' },
  { mal_id: 40748, title: 'Jujutsu Kaisen', score: 8.6, episodes: 24, year: 2020, genres:[{name:'Action'},{name:'Supernatural'}], images:{jpg:{large_image_url:'https://cdn.myanimelist.net/images/anime/1171/109222l.jpg'}}, synopsis:'Ein Schüler gerät in die gefährliche Welt verfluchter Geister.' },
  { mal_id: 21, title: 'One Piece', score: 8.7, episodes: null, year: 1999, genres:[{name:'Action'},{name:'Adventure'}], images:{jpg:{large_image_url:'https://cdn.myanimelist.net/images/anime/6/73245l.jpg'}}, synopsis:'Ruffy und seine Crew segeln auf der Suche nach dem legendären Schatz.' },
  { mal_id: 11061, title: 'Hunter x Hunter (2011)', score: 9.0, episodes: 148, year: 2011, genres:[{name:'Action'},{name:'Adventure'}], images:{jpg:{large_image_url:'https://cdn.myanimelist.net/images/anime/11/33657l.jpg'}}, synopsis:'Gon wird Hunter, um seinen Vater zu finden.' },
  { mal_id: 5114+1, title: 'Death Note', score: 8.6, episodes: 37, year: 2006, genres:[{name:'Thriller'},{name:'Supernatural'}], images:{jpg:{large_image_url:'https://cdn.myanimelist.net/images/anime/9/9453l.jpg'}}, synopsis:'Ein Schüler findet ein Notizbuch, mit dem er Menschen töten kann.' },
  { mal_id: 20, title: 'Naruto', score: 8.0, episodes: 220, year: 2002, genres:[{name:'Action'},{name:'Adventure'}], images:{jpg:{large_image_url:'https://cdn.myanimelist.net/images/anime/13/17405l.jpg'}}, synopsis:'Ein junger Ninja will eines Tages Hokage werden.' },
];

// A sizeable local catalogue means discovery and title search still work when the
// public API is rate-limited or temporarily unavailable. Online results enrich it.
function posterPlaceholder(title) {
  const safe = String(title || 'Anime').replace(/[&<>"']/g, ' ').slice(0, 34);
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="360" height="520" viewBox="0 0 360 520"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#24133f"/><stop offset=".55" stop-color="#6b35a8"/><stop offset="1" stop-color="#111827"/></linearGradient><radialGradient id="r"><stop stop-color="#c084fc" stop-opacity=".7"/><stop offset="1" stop-color="#c084fc" stop-opacity="0"/></radialGradient></defs><rect width="360" height="520" fill="url(#g)"/><circle cx="280" cy="130" r="170" fill="url(#r)"/><path d="M0 400 L150 240 L360 430 V520 H0Z" fill="#080b17" fill-opacity=".5"/><text x="22" y="420" font-family="Arial,sans-serif" font-size="14" letter-spacing="4" fill="#e9d5ff">ANIMEVAULT</text><foreignObject x="22" y="435" width="316" height="72"><div xmlns="http://www.w3.org/1999/xhtml" style="font-family:Arial,sans-serif;font-size:22px;font-weight:700;color:white;line-height:1.1;overflow:hidden;max-height:60px">${safe}</div></foreignObject></svg>`;
  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
}
const offlineCatalog = [
  { mal_id: 153, title: "Dragon Ball", title_english: "Dragon Ball", episodes: 153, year: 1986, score: null, genres: ["Action", "Adventure"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Dragon Ball"), large_image_url: posterPlaceholder("Dragon Ball") } } },
  { mal_id: 813, title: "Dragon Ball Z", title_english: "Dragon Ball Z", episodes: 291, year: 1989, score: null, genres: ["Action", "Adventure"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Dragon Ball Z"), large_image_url: posterPlaceholder("Dragon Ball Z") } } },
  { mal_id: 120, title: "Dragon Ball Super", title_english: "Dragon Ball Super", episodes: 131, year: 2015, score: null, genres: ["Action", "Adventure"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Dragon Ball Super"), large_image_url: posterPlaceholder("Dragon Ball Super") } } },
  { mal_id: 1735, title: "Naruto Shippuden", title_english: "Naruto Shippuden", episodes: 500, year: 2007, score: null, genres: ["Action", "Adventure"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Naruto Shippuden"), large_image_url: posterPlaceholder("Naruto Shippuden") } } },
  { mal_id: 34566, title: "Boruto: Naruto Next Generations", title_english: "Boruto: Naruto Next Generations", episodes: 293, year: 2017, score: null, genres: ["Action", "Adventure"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Boruto: Naruto Next Generations"), large_image_url: posterPlaceholder("Boruto: Naruto Next Generations") } } },
  { mal_id: 269, title: "Bleach", title_english: "Bleach", episodes: 366, year: 2004, score: null, genres: ["Action", "Supernatural"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Bleach"), large_image_url: posterPlaceholder("Bleach") } } },
  { mal_id: 41467, title: "Bleach: Thousand-Year Blood War", title_english: "Bleach: Thousand-Year Blood War", episodes: 13, year: 2022, score: null, genres: ["Action", "Supernatural"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Bleach: Thousand-Year Blood War"), large_image_url: posterPlaceholder("Bleach: Thousand-Year Blood War") } } },
  { mal_id: 30276, title: "One Punch Man", title_english: "One Punch Man", episodes: 12, year: 2015, score: null, genres: ["Action", "Comedy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("One Punch Man"), large_image_url: posterPlaceholder("One Punch Man") } } },
  { mal_id: 32182, title: "Mob Psycho 100", title_english: "Mob Psycho 100", episodes: 12, year: 2016, score: null, genres: ["Action", "Supernatural"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Mob Psycho 100"), large_image_url: posterPlaceholder("Mob Psycho 100") } } },
  { mal_id: 31964, title: "My Hero Academia", title_english: "My Hero Academia", episodes: 13, year: 2016, score: null, genres: ["Action", "School"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("My Hero Academia"), large_image_url: posterPlaceholder("My Hero Academia") } } },
  { mal_id: 34572, title: "Black Clover", title_english: "Black Clover", episodes: 170, year: 2017, score: null, genres: ["Action", "Fantasy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Black Clover"), large_image_url: posterPlaceholder("Black Clover") } } },
  { mal_id: 6702, title: "Fairy Tail", title_english: "Fairy Tail", episodes: 175, year: 2009, score: null, genres: ["Action", "Fantasy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Fairy Tail"), large_image_url: posterPlaceholder("Fairy Tail") } } },
  { mal_id: 11757, title: "Sword Art Online", title_english: "Sword Art Online", episodes: 25, year: 2012, score: null, genres: ["Action", "Fantasy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Sword Art Online"), large_image_url: posterPlaceholder("Sword Art Online") } } },
  { mal_id: 22319, title: "Tokyo Ghoul", title_english: "Tokyo Ghoul", episodes: 12, year: 2014, score: null, genres: ["Action", "Horror"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Tokyo Ghoul"), large_image_url: posterPlaceholder("Tokyo Ghoul") } } },
  { mal_id: 44511, title: "Chainsaw Man", title_english: "Chainsaw Man", episodes: 12, year: 2022, score: null, genres: ["Action", "Supernatural"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Chainsaw Man"), large_image_url: posterPlaceholder("Chainsaw Man") } } },
  { mal_id: 50265, title: "Spy x Family", title_english: "Spy x Family", episodes: 12, year: 2022, score: null, genres: ["Action", "Comedy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Spy x Family"), large_image_url: posterPlaceholder("Spy x Family") } } },
  { mal_id: 49596, title: "Blue Lock", title_english: "Blue Lock", episodes: 24, year: 2022, score: null, genres: ["Sports", "Drama"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Blue Lock"), large_image_url: posterPlaceholder("Blue Lock") } } },
  { mal_id: 20583, title: "Haikyu!!", title_english: "Haikyu!!", episodes: 25, year: 2014, score: null, genres: ["Sports", "Comedy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Haikyu!!"), large_image_url: posterPlaceholder("Haikyu!!") } } },
  { mal_id: 11771, title: "Kuroko no Basket", title_english: "Kuroko no Basket", episodes: 25, year: 2012, score: null, genres: ["Sports", "Drama"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Kuroko no Basket"), large_image_url: posterPlaceholder("Kuroko no Basket") } } },
  { mal_id: 170, title: "Slam Dunk", title_english: "Slam Dunk", episodes: 101, year: 1993, score: null, genres: ["Sports", "Comedy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Slam Dunk"), large_image_url: posterPlaceholder("Slam Dunk") } } },
  { mal_id: 9253, title: "Steins;Gate", title_english: "Steins;Gate", episodes: 24, year: 2011, score: null, genres: ["Sci-Fi", "Thriller"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Steins;Gate"), large_image_url: posterPlaceholder("Steins;Gate") } } },
  { mal_id: 1575, title: "Code Geass", title_english: "Code Geass", episodes: 25, year: 2006, score: null, genres: ["Action", "Sci-Fi"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Code Geass"), large_image_url: posterPlaceholder("Code Geass") } } },
  { mal_id: 1, title: "Cowboy Bebop", title_english: "Cowboy Bebop", episodes: 26, year: 1998, score: null, genres: ["Sci-Fi", "Adventure"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Cowboy Bebop"), large_image_url: posterPlaceholder("Cowboy Bebop") } } },
  { mal_id: 30, title: "Neon Genesis Evangelion", title_english: "Neon Genesis Evangelion", episodes: 26, year: 1995, score: null, genres: ["Sci-Fi", "Drama"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Neon Genesis Evangelion"), large_image_url: posterPlaceholder("Neon Genesis Evangelion") } } },
  { mal_id: 37521, title: "Vinland Saga", title_english: "Vinland Saga", episodes: 24, year: 2019, score: null, genres: ["Action", "Drama"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Vinland Saga"), large_image_url: posterPlaceholder("Vinland Saga") } } },
  { mal_id: 33, title: "Berserk", title_english: "Berserk", episodes: 25, year: 1997, score: null, genres: ["Action", "Fantasy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Berserk"), large_image_url: posterPlaceholder("Berserk") } } },
  { mal_id: 19, title: "Monster", title_english: "Monster", episodes: 74, year: 2004, score: null, genres: ["Thriller", "Drama"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Monster"), large_image_url: posterPlaceholder("Monster") } } },
  { mal_id: 13601, title: "Psycho-Pass", title_english: "Psycho-Pass", episodes: 22, year: 2012, score: null, genres: ["Sci-Fi", "Thriller"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Psycho-Pass"), large_image_url: posterPlaceholder("Psycho-Pass") } } },
  { mal_id: 22535, title: "Parasyte: The Maxim", title_english: "Parasyte: The Maxim", episodes: 24, year: 2014, score: null, genres: ["Horror", "Action"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Parasyte: The Maxim"), large_image_url: posterPlaceholder("Parasyte: The Maxim") } } },
  { mal_id: 31043, title: "Erased", title_english: "Erased", episodes: 12, year: 2016, score: null, genres: ["Thriller", "Drama"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Erased"), large_image_url: posterPlaceholder("Erased") } } },
  { mal_id: 37779, title: "The Promised Neverland", title_english: "The Promised Neverland", episodes: 12, year: 2019, score: null, genres: ["Thriller", "Horror"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("The Promised Neverland"), large_image_url: posterPlaceholder("The Promised Neverland") } } },
  { mal_id: 34599, title: "Made in Abyss", title_english: "Made in Abyss", episodes: 13, year: 2017, score: null, genres: ["Fantasy", "Adventure"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Made in Abyss"), large_image_url: posterPlaceholder("Made in Abyss") } } },
  { mal_id: 31240, title: "Re:Zero", title_english: "Re:Zero", episodes: 25, year: 2016, score: null, genres: ["Fantasy", "Drama"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Re:Zero"), large_image_url: posterPlaceholder("Re:Zero") } } },
  { mal_id: 39535, title: "Mushoku Tensei", title_english: "Mushoku Tensei", episodes: 11, year: 2021, score: null, genres: ["Fantasy", "Adventure"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Mushoku Tensei"), large_image_url: posterPlaceholder("Mushoku Tensei") } } },
  { mal_id: 37430, title: "That Time I Got Reincarnated as a Slime", title_english: "That Time I Got Reincarnated as a Slime", episodes: 24, year: 2018, score: null, genres: ["Fantasy", "Comedy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("That Time I Got Reincarnated as a Slime"), large_image_url: posterPlaceholder("That Time I Got Reincarnated as a Slime") } } },
  { mal_id: 29803, title: "Overlord", title_english: "Overlord", episodes: 13, year: 2015, score: null, genres: ["Fantasy", "Action"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Overlord"), large_image_url: posterPlaceholder("Overlord") } } },
  { mal_id: 30831, title: "Konosuba", title_english: "Konosuba", episodes: 10, year: 2016, score: null, genres: ["Fantasy", "Comedy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Konosuba"), large_image_url: posterPlaceholder("Konosuba") } } },
  { mal_id: 52991, title: "Frieren: Beyond Journey’s End", title_english: "Frieren: Beyond Journey’s End", episodes: 28, year: 2023, score: null, genres: ["Fantasy", "Adventure"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Frieren: Beyond Journey’s End"), large_image_url: posterPlaceholder("Frieren: Beyond Journey’s End") } } },
  { mal_id: 54492, title: "The Apothecary Diaries", title_english: "The Apothecary Diaries", episodes: 24, year: 2023, score: null, genres: ["Drama", "Mystery"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("The Apothecary Diaries"), large_image_url: posterPlaceholder("The Apothecary Diaries") } } },
  { mal_id: 52299, title: "Solo Leveling", title_english: "Solo Leveling", episodes: 12, year: 2024, score: null, genres: ["Action", "Fantasy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Solo Leveling"), large_image_url: posterPlaceholder("Solo Leveling") } } },
  { mal_id: 52588, title: "Kaiju No. 8", title_english: "Kaiju No. 8", episodes: 12, year: 2024, score: null, genres: ["Action", "Sci-Fi"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Kaiju No. 8"), large_image_url: posterPlaceholder("Kaiju No. 8") } } },
  { mal_id: 38691, title: "Dr. Stone", title_english: "Dr. Stone", episodes: 24, year: 2019, score: null, genres: ["Adventure", "Sci-Fi"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Dr. Stone"), large_image_url: posterPlaceholder("Dr. Stone") } } },
  { mal_id: 23755, title: "The Seven Deadly Sins", title_english: "The Seven Deadly Sins", episodes: 24, year: 2014, score: null, genres: ["Action", "Fantasy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("The Seven Deadly Sins"), large_image_url: posterPlaceholder("The Seven Deadly Sins") } } },
  { mal_id: 249, title: "Inuyasha", title_english: "Inuyasha", episodes: 167, year: 2000, score: null, genres: ["Action", "Fantasy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Inuyasha"), large_image_url: posterPlaceholder("Inuyasha") } } },
  { mal_id: 45, title: "Rurouni Kenshin", title_english: "Rurouni Kenshin", episodes: 94, year: 1996, score: null, genres: ["Action", "Adventure"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Rurouni Kenshin"), large_image_url: posterPlaceholder("Rurouni Kenshin") } } },
  { mal_id: 392, title: "Yu Yu Hakusho", title_english: "Yu Yu Hakusho", episodes: 112, year: 1992, score: null, genres: ["Action", "Supernatural"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Yu Yu Hakusho"), large_image_url: posterPlaceholder("Yu Yu Hakusho") } } },
  { mal_id: 14719, title: "JoJo’s Bizarre Adventure", title_english: "JoJo’s Bizarre Adventure", episodes: 26, year: 2012, score: null, genres: ["Action", "Adventure"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("JoJo’s Bizarre Adventure"), large_image_url: posterPlaceholder("JoJo’s Bizarre Adventure") } } },
  { mal_id: 10087, title: "Fate/Zero", title_english: "Fate/Zero", episodes: 13, year: 2011, score: null, genres: ["Action", "Fantasy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Fate/Zero"), large_image_url: posterPlaceholder("Fate/Zero") } } },
  { mal_id: 22297, title: "Fate/stay night: Unlimited Blade Works", title_english: "Fate/stay night: Unlimited Blade Works", episodes: 12, year: 2014, score: null, genres: ["Action", "Fantasy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Fate/stay night: Unlimited Blade Works"), large_image_url: posterPlaceholder("Fate/stay night: Unlimited Blade Works") } } },
  { mal_id: 777, title: "Hellsing Ultimate", title_english: "Hellsing Ultimate", episodes: 10, year: 2006, score: null, genres: ["Action", "Horror"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Hellsing Ultimate"), large_image_url: posterPlaceholder("Hellsing Ultimate") } } },
  { mal_id: 6, title: "Trigun", title_english: "Trigun", episodes: 26, year: 1998, score: null, genres: ["Action", "Sci-Fi"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Trigun"), large_image_url: posterPlaceholder("Trigun") } } },
  { mal_id: 205, title: "Samurai Champloo", title_english: "Samurai Champloo", episodes: 26, year: 2004, score: null, genres: ["Action", "Adventure"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Samurai Champloo"), large_image_url: posterPlaceholder("Samurai Champloo") } } },
  { mal_id: 33255, title: "The Disastrous Life of Saiki K.", title_english: "The Disastrous Life of Saiki K.", episodes: 120, year: 2016, score: null, genres: ["Comedy", "Supernatural"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("The Disastrous Life of Saiki K."), large_image_url: posterPlaceholder("The Disastrous Life of Saiki K.") } } },
  { mal_id: 37999, title: "Kaguya-sama: Love is War", title_english: "Kaguya-sama: Love is War", episodes: 12, year: 2019, score: null, genres: ["Romance", "Comedy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Kaguya-sama: Love is War"), large_image_url: posterPlaceholder("Kaguya-sama: Love is War") } } },
  { mal_id: 4224, title: "Toradora!", title_english: "Toradora!", episodes: 25, year: 2008, score: null, genres: ["Romance", "Comedy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Toradora!"), large_image_url: posterPlaceholder("Toradora!") } } },
  { mal_id: 23273, title: "Your Lie in April", title_english: "Your Lie in April", episodes: 22, year: 2014, score: null, genres: ["Romance", "Drama"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Your Lie in April"), large_image_url: posterPlaceholder("Your Lie in April") } } },
  { mal_id: 2167, title: "Clannad", title_english: "Clannad", episodes: 23, year: 2007, score: null, genres: ["Romance", "Drama"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Clannad"), large_image_url: posterPlaceholder("Clannad") } } },
  { mal_id: 38680, title: "Fruits Basket", title_english: "Fruits Basket", episodes: 25, year: 2019, score: null, genres: ["Romance", "Drama"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Fruits Basket"), large_image_url: posterPlaceholder("Fruits Basket") } } },
  { mal_id: 42897, title: "Horimiya", title_english: "Horimiya", episodes: 13, year: 2021, score: null, genres: ["Romance", "Comedy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Horimiya"), large_image_url: posterPlaceholder("Horimiya") } } },
  { mal_id: 32281, title: "Your Name", title_english: "Your Name", episodes: 1, year: 2016, score: null, genres: ["Romance", "Drama"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Your Name"), large_image_url: posterPlaceholder("Your Name") } } },
  { mal_id: 28851, title: "A Silent Voice", title_english: "A Silent Voice", episodes: 1, year: 2016, score: null, genres: ["Drama", "Romance"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("A Silent Voice"), large_image_url: posterPlaceholder("A Silent Voice") } } },
  { mal_id: 38826, title: "Weathering with You", title_english: "Weathering with You", episodes: 1, year: 2019, score: null, genres: ["Romance", "Fantasy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Weathering with You"), large_image_url: posterPlaceholder("Weathering with You") } } },
  { mal_id: 199, title: "Spirited Away", title_english: "Spirited Away", episodes: 1, year: 2001, score: null, genres: ["Fantasy", "Adventure"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Spirited Away"), large_image_url: posterPlaceholder("Spirited Away") } } },
  { mal_id: 431, title: "Howl’s Moving Castle", title_english: "Howl’s Moving Castle", episodes: 1, year: 2004, score: null, genres: ["Fantasy", "Adventure"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Howl’s Moving Castle"), large_image_url: posterPlaceholder("Howl’s Moving Castle") } } },
  { mal_id: 164, title: "Princess Mononoke", title_english: "Princess Mononoke", episodes: 1, year: 1997, score: null, genres: ["Fantasy", "Adventure"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Princess Mononoke"), large_image_url: posterPlaceholder("Princess Mononoke") } } },
  { mal_id: 523, title: "My Neighbor Totoro", title_english: "My Neighbor Totoro", episodes: 1, year: 1988, score: null, genres: ["Fantasy", "Family"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("My Neighbor Totoro"), large_image_url: posterPlaceholder("My Neighbor Totoro") } } },
  { mal_id: 2890, title: "Ponyo", title_english: "Ponyo", episodes: 1, year: 2008, score: null, genres: ["Fantasy", "Family"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Ponyo"), large_image_url: posterPlaceholder("Ponyo") } } },
  { mal_id: 918, title: "Gintama", title_english: "Gintama", episodes: 201, year: 2006, score: null, genres: ["Comedy", "Action"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Gintama"), large_image_url: posterPlaceholder("Gintama") } } },
  { mal_id: 31478, title: "Bungo Stray Dogs", title_english: "Bungo Stray Dogs", episodes: 12, year: 2016, score: null, genres: ["Action", "Supernatural"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Bungo Stray Dogs"), large_image_url: posterPlaceholder("Bungo Stray Dogs") } } },
  { mal_id: 6746, title: "Durarara!!", title_english: "Durarara!!", episodes: 24, year: 2010, score: null, genres: ["Action", "Mystery"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Durarara!!"), large_image_url: posterPlaceholder("Durarara!!") } } },
  { mal_id: 47917, title: "Bocchi the Rock!", title_english: "Bocchi the Rock!", episodes: 12, year: 2022, score: null, genres: ["Comedy", "Music"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Bocchi the Rock!"), large_image_url: posterPlaceholder("Bocchi the Rock!") } } },
  { mal_id: 5680, title: "K-On!", title_english: "K-On!", episodes: 13, year: 2009, score: null, genres: ["Comedy", "Music"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("K-On!"), large_image_url: posterPlaceholder("K-On!") } } },
  { mal_id: 33352, title: "Violet Evergarden", title_english: "Violet Evergarden", episodes: 13, year: 2018, score: null, genres: ["Drama", "Fantasy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Violet Evergarden"), large_image_url: posterPlaceholder("Violet Evergarden") } } },
  { mal_id: 31646, title: "March Comes in Like a Lion", title_english: "March Comes in Like a Lion", episodes: 22, year: 2016, score: null, genres: ["Drama", "Slice of Life"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("March Comes in Like a Lion"), large_image_url: posterPlaceholder("March Comes in Like a Lion") } } },
  { mal_id: 877, title: "Nana", title_english: "Nana", episodes: 47, year: 2006, score: null, genres: ["Drama", "Music"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Nana"), large_image_url: posterPlaceholder("Nana") } } },
  { mal_id: 853, title: "Ouran High School Host Club", title_english: "Ouran High School Host Club", episodes: 26, year: 2006, score: null, genres: ["Romance", "Comedy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Ouran High School Host Club"), large_image_url: posterPlaceholder("Ouran High School Host Club") } } },
  { mal_id: 38101, title: "The Quintessential Quintuplets", title_english: "The Quintessential Quintuplets", episodes: 12, year: 2019, score: null, genres: ["Romance", "Comedy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("The Quintessential Quintuplets"), large_image_url: posterPlaceholder("The Quintessential Quintuplets") } } },
  { mal_id: 40839, title: "Rent-a-Girlfriend", title_english: "Rent-a-Girlfriend", episodes: 12, year: 2020, score: null, genres: ["Romance", "Comedy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Rent-a-Girlfriend"), large_image_url: posterPlaceholder("Rent-a-Girlfriend") } } },
  { mal_id: 28171, title: "Food Wars!", title_english: "Food Wars!", episodes: 24, year: 2015, score: null, genres: ["Comedy", "Food"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Food Wars!"), large_image_url: posterPlaceholder("Food Wars!") } } },
  { mal_id: 185, title: "Initial D", title_english: "Initial D", episodes: 26, year: 1998, score: null, genres: ["Sports", "Action"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Initial D"), large_image_url: posterPlaceholder("Initial D") } } },
  { mal_id: 263, title: "Hajime no Ippo", title_english: "Hajime no Ippo", episodes: 75, year: 2000, score: null, genres: ["Sports", "Drama"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Hajime no Ippo"), large_image_url: posterPlaceholder("Hajime no Ippo") } } },
  { mal_id: 32995, title: "Yuri!!! on Ice", title_english: "Yuri!!! on Ice", episodes: 12, year: 2016, score: null, genres: ["Sports", "Drama"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Yuri!!! on Ice"), large_image_url: posterPlaceholder("Yuri!!! on Ice") } } },
  { mal_id: 18507, title: "Free!", title_english: "Free!", episodes: 12, year: 2013, score: null, genres: ["Sports", "Drama"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Free!"), large_image_url: posterPlaceholder("Free!") } } },
  { mal_id: 235, title: "Detective Conan", title_english: "Detective Conan", episodes: 1000, year: 1996, score: null, genres: ["Mystery", "Adventure"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Detective Conan"), large_image_url: posterPlaceholder("Detective Conan") } } },
  { mal_id: 1412, title: "Lupin III", title_english: "Lupin III", episodes: 23, year: 1971, score: null, genres: ["Action", "Adventure"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Lupin III"), large_image_url: posterPlaceholder("Lupin III") } } },
  { mal_id: 966, title: "Crayon Shin-chan", title_english: "Crayon Shin-chan", episodes: 1000, year: 1992, score: null, genres: ["Comedy", "Family"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Crayon Shin-chan"), large_image_url: posterPlaceholder("Crayon Shin-chan") } } },
  { mal_id: 527, title: "Pokémon", title_english: "Pokémon", episodes: 1000, year: 1997, score: null, genres: ["Adventure", "Fantasy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Pokémon"), large_image_url: posterPlaceholder("Pokémon") } } },
  { mal_id: 552, title: "Digimon Adventure", title_english: "Digimon Adventure", episodes: 54, year: 1999, score: null, genres: ["Adventure", "Fantasy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Digimon Adventure"), large_image_url: posterPlaceholder("Digimon Adventure") } } },
  { mal_id: 530, title: "Sailor Moon", title_english: "Sailor Moon", episodes: 46, year: 1992, score: null, genres: ["Fantasy", "Romance"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Sailor Moon"), large_image_url: posterPlaceholder("Sailor Moon") } } },
  { mal_id: 232, title: "Cardcaptor Sakura", title_english: "Cardcaptor Sakura", episodes: 70, year: 1998, score: null, genres: ["Fantasy", "Adventure"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Cardcaptor Sakura"), large_image_url: posterPlaceholder("Cardcaptor Sakura") } } },
  { mal_id: 1482, title: "D.Gray-man", title_english: "D.Gray-man", episodes: 103, year: 2006, score: null, genres: ["Action", "Supernatural"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("D.Gray-man"), large_image_url: posterPlaceholder("D.Gray-man") } } },
  { mal_id: 3588, title: "Soul Eater", title_english: "Soul Eater", episodes: 51, year: 2008, score: null, genres: ["Action", "Fantasy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Soul Eater"), large_image_url: posterPlaceholder("Soul Eater") } } },
  { mal_id: 38671, title: "Fire Force", title_english: "Fire Force", episodes: 24, year: 2019, score: null, genres: ["Action", "Sci-Fi"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Fire Force"), large_image_url: posterPlaceholder("Fire Force") } } },
  { mal_id: 35790, title: "The Rising of the Shield Hero", title_english: "The Rising of the Shield Hero", episodes: 25, year: 2019, score: null, genres: ["Action", "Fantasy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("The Rising of the Shield Hero"), large_image_url: posterPlaceholder("The Rising of the Shield Hero") } } },
  { mal_id: 22199, title: "Akame ga Kill!", title_english: "Akame ga Kill!", episodes: 24, year: 2014, score: null, genres: ["Action", "Fantasy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Akame ga Kill!"), large_image_url: posterPlaceholder("Akame ga Kill!") } } },
  { mal_id: 18679, title: "Kill la Kill", title_english: "Kill la Kill", episodes: 24, year: 2013, score: null, genres: ["Action", "Comedy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Kill la Kill"), large_image_url: posterPlaceholder("Kill la Kill") } } },
  { mal_id: 42310, title: "Cyberpunk: Edgerunners", title_english: "Cyberpunk: Edgerunners", episodes: 10, year: 2022, score: null, genres: ["Action", "Sci-Fi"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Cyberpunk: Edgerunners"), large_image_url: posterPlaceholder("Cyberpunk: Edgerunners") } } },
  { mal_id: 35120, title: "Devilman Crybaby", title_english: "Devilman Crybaby", episodes: 10, year: 2018, score: null, genres: ["Action", "Horror"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Devilman Crybaby"), large_image_url: posterPlaceholder("Devilman Crybaby") } } },
  { mal_id: 52215, title: "Pluto", title_english: "Pluto", episodes: 8, year: 2023, score: null, genres: ["Sci-Fi", "Thriller"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Pluto"), large_image_url: posterPlaceholder("Pluto") } } },
  { mal_id: 46102, title: "Odd Taxi", title_english: "Odd Taxi", episodes: 13, year: 2021, score: null, genres: ["Mystery", "Drama"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Odd Taxi"), large_image_url: posterPlaceholder("Odd Taxi") } } },
  { mal_id: 40834, title: "Ranking of Kings", title_english: "Ranking of Kings", episodes: 23, year: 2021, score: null, genres: ["Adventure", "Fantasy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Ranking of Kings"), large_image_url: posterPlaceholder("Ranking of Kings") } } },
  { mal_id: 35062, title: "The Ancient Magus’ Bride", title_english: "The Ancient Magus’ Bride", episodes: 24, year: 2017, score: null, genres: ["Fantasy", "Romance"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("The Ancient Magus’ Bride"), large_image_url: posterPlaceholder("The Ancient Magus’ Bride") } } },
  { mal_id: 41025, title: "To Your Eternity", title_english: "To Your Eternity", episodes: 20, year: 2021, score: null, genres: ["Adventure", "Drama"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("To Your Eternity"), large_image_url: posterPlaceholder("To Your Eternity") } } },
  { mal_id: 6547, title: "Angel Beats!", title_english: "Angel Beats!", episodes: 13, year: 2010, score: null, genres: ["Drama", "Supernatural"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Angel Beats!"), large_image_url: posterPlaceholder("Angel Beats!") } } },
  { mal_id: 11111, title: "Another", title_english: "Another", episodes: 12, year: 2012, score: null, genres: ["Horror", "Mystery"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Another"), large_image_url: posterPlaceholder("Another") } } },
  { mal_id: 12189, title: "Hyouka", title_english: "Hyouka", episodes: 22, year: 2012, score: null, genres: ["Mystery", "Slice of Life"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Hyouka"), large_image_url: posterPlaceholder("Hyouka") } } },
  { mal_id: 10165, title: "Nichijou", title_english: "Nichijou", episodes: 26, year: 2011, score: null, genres: ["Comedy", "Slice of Life"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Nichijou"), large_image_url: posterPlaceholder("Nichijou") } } },
  { mal_id: 11843, title: "Daily Lives of High School Boys", title_english: "Daily Lives of High School Boys", episodes: 12, year: 2012, score: null, genres: ["Comedy", "School"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Daily Lives of High School Boys"), large_image_url: posterPlaceholder("Daily Lives of High School Boys") } } },
  { mal_id: 7785, title: "The Tatami Galaxy", title_english: "The Tatami Galaxy", episodes: 11, year: 2010, score: null, genres: ["Drama", "Comedy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("The Tatami Galaxy"), large_image_url: posterPlaceholder("The Tatami Galaxy") } } },
  { mal_id: 245, title: "Great Teacher Onizuka", title_english: "Great Teacher Onizuka", episodes: 43, year: 1999, score: null, genres: ["Comedy", "Drama"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Great Teacher Onizuka"), large_image_url: posterPlaceholder("Great Teacher Onizuka") } } },
  { mal_id: 20785, title: "The Irregular at Magic High School", title_english: "The Irregular at Magic High School", episodes: 26, year: 2014, score: null, genres: ["Fantasy", "Action"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("The Irregular at Magic High School"), large_image_url: posterPlaceholder("The Irregular at Magic High School") } } },
  { mal_id: 48316, title: "The Eminence in Shadow", title_english: "The Eminence in Shadow", episodes: 20, year: 2022, score: null, genres: ["Action", "Fantasy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("The Eminence in Shadow"), large_image_url: posterPlaceholder("The Eminence in Shadow") } } },
  { mal_id: 52701, title: "Delicious in Dungeon", title_english: "Delicious in Dungeon", episodes: 24, year: 2024, score: null, genres: ["Fantasy", "Comedy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Delicious in Dungeon"), large_image_url: posterPlaceholder("Delicious in Dungeon") } } },
  { mal_id: 57334, title: "Dandadan", title_english: "Dandadan", episodes: 12, year: 2024, score: null, genres: ["Action", "Supernatural"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Dandadan"), large_image_url: posterPlaceholder("Dandadan") } } },
  { mal_id: 56148, title: "The Elusive Samurai", title_english: "The Elusive Samurai", episodes: 12, year: 2024, score: null, genres: ["Action", "Adventure"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("The Elusive Samurai"), large_image_url: posterPlaceholder("The Elusive Samurai") } } },
  { mal_id: 54900, title: "Wind Breaker", title_english: "Wind Breaker", episodes: 13, year: 2024, score: null, genres: ["Action", "School"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Wind Breaker"), large_image_url: posterPlaceholder("Wind Breaker") } } },
  { mal_id: 52211, title: "Mashle: Magic and Muscles", title_english: "Mashle: Magic and Muscles", episodes: 12, year: 2023, score: null, genres: ["Action", "Comedy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Mashle: Magic and Muscles"), large_image_url: posterPlaceholder("Mashle: Magic and Muscles") } } },
  { mal_id: 52741, title: "Undead Unluck", title_english: "Undead Unluck", episodes: 24, year: 2023, score: null, genres: ["Action", "Supernatural"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Undead Unluck"), large_image_url: posterPlaceholder("Undead Unluck") } } },
  { mal_id: 54883, title: "The Wrong Way to Use Healing Magic", title_english: "The Wrong Way to Use Healing Magic", episodes: 13, year: 2024, score: null, genres: ["Fantasy", "Comedy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("The Wrong Way to Use Healing Magic"), large_image_url: posterPlaceholder("The Wrong Way to Use Healing Magic") } } },
  { mal_id: 52347, title: "Shangri-La Frontier", title_english: "Shangri-La Frontier", episodes: 25, year: 2023, score: null, genres: ["Action", "Fantasy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Shangri-La Frontier"), large_image_url: posterPlaceholder("Shangri-La Frontier") } } },
  { mal_id: 52578, title: "The Dangers in My Heart", title_english: "The Dangers in My Heart", episodes: 12, year: 2023, score: null, genres: ["Romance", "Comedy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("The Dangers in My Heart"), large_image_url: posterPlaceholder("The Dangers in My Heart") } } },
  { mal_id: 50796, title: "Insomniacs After School", title_english: "Insomniacs After School", episodes: 13, year: 2023, score: null, genres: ["Romance", "Drama"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Insomniacs After School"), large_image_url: posterPlaceholder("Insomniacs After School") } } },
  { mal_id: 50416, title: "Skip and Loafer", title_english: "Skip and Loafer", episodes: 12, year: 2023, score: null, genres: ["Romance", "Slice of Life"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Skip and Loafer"), large_image_url: posterPlaceholder("Skip and Loafer") } } },
  { mal_id: 35839, title: "A Place Further Than the Universe", title_english: "A Place Further Than the Universe", episodes: 13, year: 2018, score: null, genres: ["Adventure", "Drama"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("A Place Further Than the Universe"), large_image_url: posterPlaceholder("A Place Further Than the Universe") } } },
  { mal_id: 34798, title: "Laid-Back Camp", title_english: "Laid-Back Camp", episodes: 12, year: 2018, score: null, genres: ["Slice of Life", "Comedy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Laid-Back Camp"), large_image_url: posterPlaceholder("Laid-Back Camp") } } },
  { mal_id: 22789, title: "Barakamon", title_english: "Barakamon", episodes: 12, year: 2014, score: null, genres: ["Slice of Life", "Comedy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Barakamon"), large_image_url: posterPlaceholder("Barakamon") } } },
  { mal_id: 16918, title: "Silver Spoon", title_english: "Silver Spoon", episodes: 11, year: 2013, score: null, genres: ["Slice of Life", "Comedy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Silver Spoon"), large_image_url: posterPlaceholder("Silver Spoon") } } },
  { mal_id: 46352, title: "Blue Period", title_english: "Blue Period", episodes: 12, year: 2021, score: null, genres: ["Drama", "Slice of Life"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Blue Period"), large_image_url: posterPlaceholder("Blue Period") } } },
  { mal_id: 39195, title: "Beastars", title_english: "Beastars", episodes: 12, year: 2019, score: null, genres: ["Drama", "Fantasy"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Beastars"), large_image_url: posterPlaceholder("Beastars") } } },
  { mal_id: 48580, title: "The Case Study of Vanitas", title_english: "The Case Study of Vanitas", episodes: 12, year: 2021, score: null, genres: ["Action", "Supernatural"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("The Case Study of Vanitas"), large_image_url: posterPlaceholder("The Case Study of Vanitas") } } },
  { mal_id: 31757, title: "The Garden of Sinners", title_english: "The Garden of Sinners", episodes: 1, year: 2007, score: null, genres: ["Mystery", "Supernatural"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("The Garden of Sinners"), large_image_url: posterPlaceholder("The Garden of Sinners") } } },
  { mal_id: 47, title: "Akira", title_english: "Akira", episodes: 1, year: 1988, score: null, genres: ["Sci-Fi", "Action"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Akira"), large_image_url: posterPlaceholder("Akira") } } },
  { mal_id: 43, title: "Ghost in the Shell", title_english: "Ghost in the Shell", episodes: 1, year: 1995, score: null, genres: ["Sci-Fi", "Thriller"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Ghost in the Shell"), large_image_url: posterPlaceholder("Ghost in the Shell") } } },
  { mal_id: 437, title: "Perfect Blue", title_english: "Perfect Blue", episodes: 1, year: 1997, score: null, genres: ["Thriller", "Horror"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Perfect Blue"), large_image_url: posterPlaceholder("Perfect Blue") } } },
  { mal_id: 1943, title: "Paprika", title_english: "Paprika", episodes: 1, year: 2006, score: null, genres: ["Sci-Fi", "Thriller"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Paprika"), large_image_url: posterPlaceholder("Paprika") } } },
  { mal_id: 2236, title: "The Girl Who Leapt Through Time", title_english: "The Girl Who Leapt Through Time", episodes: 1, year: 2006, score: null, genres: ["Sci-Fi", "Romance"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("The Girl Who Leapt Through Time"), large_image_url: posterPlaceholder("The Girl Who Leapt Through Time") } } },
  { mal_id: 5681, title: "Summer Wars", title_english: "Summer Wars", episodes: 1, year: 2009, score: null, genres: ["Sci-Fi", "Family"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Summer Wars"), large_image_url: posterPlaceholder("Summer Wars") } } },
  { mal_id: 6675, title: "Redline", title_english: "Redline", episodes: 1, year: 2009, score: null, genres: ["Action", "Sci-Fi"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Redline"), large_image_url: posterPlaceholder("Redline") } } },
  { mal_id: 35848, title: "Promare", title_english: "Promare", episodes: 1, year: 2019, score: null, genres: ["Action", "Sci-Fi"].map(name=>({name})), synopsis: '', images: { jpg: { image_url: posterPlaceholder("Promare"), large_image_url: posterPlaceholder("Promare") } } },
];
// Extra offline titles: these remain browseable even when both public APIs are down.
const extraOfflineCatalog = [
  [1,'Cowboy Bebop',26,1998,['Sci-Fi','Action']], [6,'Trigun',26,1998,['Action','Sci-Fi']],
  [30,'Neon Genesis Evangelion',26,1995,['Mecha','Drama']], [199,'Sen to Chihiro no Kamikakushi',1,2001,['Fantasy','Adventure']],
  [2001,'Tengen Toppa Gurren Lagann',27,2007,['Mecha','Action']], [205,'Samurai Champloo',26,2004,['Action','Adventure']],
  [2251,'Baccano!',13,2007,['Mystery','Action']], [6702,'Fairy Tail',175,2009,['Action','Fantasy']],
  [11757,'Sword Art Online',25,2012,['Action','Fantasy']], [30240,'Prison School',12,2015,['Comedy']],
  [31964,'Boku no Hero Academia',13,2016,['Action','Superhero']], [33486,'Boku no Hero Academia 2',25,2017,['Action','Superhero']],
  [36456,'Boku no Hero Academia 3',25,2018,['Action','Superhero']], [38408,'Boku no Hero Academia 4',25,2019,['Action','Superhero']],
  [48561,'Chainsaw Man',12,2022,['Action','Horror']], [42310,'Cyberpunk: Edgerunners',10,2022,['Sci-Fi','Action']],
  [39535,'Mushoku Tensei',11,2021,['Fantasy','Adventure']], [44006,'Mushoku Tensei II',25,2023,['Fantasy','Adventure']],
  [38691,'Dr. Stone',24,2019,['Adventure','Sci-Fi']], [40852,'Dr. Stone: Stone Wars',11,2021,['Adventure','Sci-Fi']],
  [37999,'Kaguya-sama: Love is War',12,2019,['Romance','Comedy']], [40591,'Kaguya-sama: Love is War?',12,2020,['Romance','Comedy']],
  [4181,'Clannad: After Story',24,2008,['Drama','Romance']], [1575,'Code Geass',25,2006,['Mecha','Thriller']],
  [30205,'Akagami no Shirayuki-hime',12,2015,['Romance','Fantasy']], [33352,'Violet Evergarden',13,2018,['Drama']],
  [38826,'Tenki no Ko',1,2019,['Romance','Fantasy']], [28851,'Koe no Katachi',1,2016,['Drama','Romance']],
  [9253,'Steins;Gate',24,2011,['Sci-Fi','Thriller']], [31240,'Re:Zero',25,2016,['Fantasy','Drama']],
  [39587,'Re:Zero Season 2',25,2020,['Fantasy','Drama']], [42203,'Spy x Family',12,2022,['Action','Comedy']],
  [53887,'Spy x Family Season 2',12,2023,['Action','Comedy']], [47917,'Blue Lock',24,2022,['Sports']],
  [30230,'Diamond no Ace',75,2013,['Sports']], [11771,'Kuroko no Basket',25,2012,['Sports']],
  [24415,'Kuroko no Basket 2',25,2013,['Sports']], [20583,'Haikyuu!!',25,2014,['Sports','Comedy']],
  [28891,'Haikyuu!! Second Season',25,2015,['Sports','Comedy']], [35760,'Shokugeki no Souma',24,2015,['Comedy']],
  [40730,'Tensei Shitara Slime Datta Ken',24,2018,['Fantasy','Adventure']], [39551,'Tensei Shitara Slime Datta Ken 2',12,2021,['Fantasy','Adventure']],
  [51009,'Kusuriya no Hitorigoto',24,2023,['Mystery','Drama']], [54492,'Solo Leveling',12,2024,['Action','Fantasy']],
  [58567,'Kaiju No. 8',12,2024,['Action','Sci-Fi']], [57334,'Dandadan',12,2024,['Action','Supernatural']],
  [56865,'Sakamoto Days',11,2025,['Action','Comedy']], [58939,'The Apothecary Diaries Season 2',24,2025,['Mystery','Drama']],
  [52807,'Oshi no Ko',11,2023,['Drama','Mystery']], [55791,'Oshi no Ko Season 2',13,2024,['Drama','Mystery']],
  [37982,'Domestic na Kanojo',12,2019,['Romance','Drama']], [35062,'Yuru Camp Season 2',13,2021,['Slice of Life']],
  [52034,'Bocchi the Rock!',12,2022,['Comedy','Music']], [50709,'Lycoris Recoil',13,2022,['Action','Drama']],
  [50160,'The Eminence in Shadow',20,2022,['Action','Fantasy']], [54857,'The Eminence in Shadow Season 2',12,2023,['Action','Fantasy']],
  [49701,'Tomodachi Game',12,2022,['Thriller','Psychological']], [50273,'Call of the Night',13,2022,['Romance','Supernatural']],
  [52082,'The Angel Next Door Spoils Me Rotten',12,2023,['Romance']], [52505,'My Love Story with Yamada-kun at Lv999',13,2023,['Romance','Comedy']],
  [52826,'Frieren: Beyond Journey’s End',28,2023,['Fantasy','Adventure']], [54835,'The Elusive Samurai',12,2024,['Action','Adventure']],
  [53716,'Delicious in Dungeon',24,2024,['Fantasy','Comedy']], [53411,'The New Gate',12,2024,['Fantasy','Action']],
  [51096,'The Reincarnation of the Strongest Exorcist',13,2023,['Fantasy','Action']], [49891,'My Happy Marriage',12,2023,['Romance','Fantasy']],
  [53050,'The Seven Deadly Sins: Four Knights of the Apocalypse',24,2023,['Action','Fantasy']], [50613,'Ragna Crimson',24,2023,['Action','Fantasy']],
  [50265,'The Kingdoms of Ruin',12,2023,['Action','Fantasy']], [52305,'A Returner’s Magic Should Be Special',12,2023,['Fantasy','Action']],
  [54856,'Wistoria: Wand and Sword',12,2024,['Action','Fantasy']], [52588,'The Iceblade Sorcerer Shall Rule the World',12,2023,['Fantasy','Action']],
];
const extraIds = new Set(offlineCatalog.map(a=>a.mal_id));
for (const [mal_id,title,episodes,year,genreNames] of extraOfflineCatalog) {
  if (extraIds.has(mal_id)) continue;
  const cover = posterPlaceholder(title);
  offlineCatalog.push({ mal_id, title, title_english:title, episodes, year, score:null, genres:genreNames.map(name=>({name})), synopsis:'', images:{jpg:{image_url:cover,large_image_url:cover}} });
}

// Curated hints only for well-known releases. Everything else is explicitly unverified,
// because anime metadata APIs do not reliably provide the audio tracks for each region.
const knownGermanDubs = new Set([
  'attackontitan','shingekinokyojin','demonslayer','kimetsunoyaiba','jujutsukaisen',
  'onepiece','naruto','narutoshippuden','deathnote','fullmetalalchemistbrotherhood',
  'dragonball','dragonballz','dragonballsuper','bleach','myheroacademia','bokunoheroacademia',
  'chainsawman','spyxfamily','hunterxhunter2011','swordartonline','cowboybebop','deathnote',
  'violetevergarden','cyberpunkedgerunners','solo leveling','sololeveling','frierenbeyondjourneysend',
  'haikyuu','haikyuu!!','tokyoghoul','blackclover','fairytail','onepunchman','mobpsycho100',
  'jojosbizarreadventure','jojo’sbizarreadventure','codegeass','steinsgate','drstone','rezerostartinglifeinanotherworld'
].map(x=>x.replace(/[^a-z0-9]/g,'')));
const navItems = [{id:'home',label:'Startseite',Icon:Sparkles},{id:'discover',label:'Entdecken',Icon:Compass},{id:'swipe',label:'Swipe-Modus',Icon:Heart},{id:'list',label:'Meine Liste',Icon:Bookmark},{id:'calendar',label:'Release Radar',Icon:CalendarDays},{id:'franchise',label:'Franchise',Icon:GitBranch},{id:'profile',label:'Profil & Erfolge',Icon:Trophy},{id:'community',label:'Community',Icon:Users},{id:'stats',label:'Statistiken',Icon:BarChart3}];
const readList = () => { try { return JSON.parse(localStorage.getItem('animevault-list') || '{}'); } catch { return {}; } };
const readStore = (key, fallback) => { try { const value=JSON.parse(localStorage.getItem(key) || 'null'); return value ?? fallback; } catch { return fallback; } };
const writeStore = (key, value) => { try { localStorage.setItem(key, JSON.stringify(value)); } catch {} };

function App(){
  const discoverInitialized = useRef(false);
  const [sharedProfile,setSharedProfile]=useState(()=>{try{const m=location.hash.match(/#share=([^&]+)/);return m?JSON.parse(decodeURIComponent(escape(atob(m[1])))):null;}catch{return null;}});
  const [page,setPage]=useState('home'); const [anime,setAnime]=useState(offlineCatalog); const [watchlist,setWatchlist]=useState(readList);
  const [query,setQuery]=useState(''); const [genre,setGenre]=useState('Alle'); const [status,setStatus]=useState('Alle'); const [dubFilter,setDubFilter]=useState('Alle'); const [relatedAnime,setRelatedAnime]=useState([]); const [selected,setSelected]=useState(null); const [loading,setLoading]=useState(false); const [error,setError]=useState(''); const [toast,setToast]=useState(''); const [apiPage,setApiPage]=useState(1); const [hasMore,setHasMore]=useState(false); const [searchMode,setSearchMode]=useState('top'); const [homeCatalog,setHomeCatalog]=useState([...starter, ...offlineCatalog]); const [homeTrending,setHomeTrending]=useState([]); const [homeIndices,setHomeIndices]=useState({popular:0,action:0,fantasy:0,trending:0,airing:0});
  const [likedIds,setLikedIds]=useState(()=>readStore('animevault-liked',[])); const [dislikedIds,setDislikedIds]=useState(()=>readStore('animevault-disliked',[])); const [swipeHistory,setSwipeHistory]=useState([]); const [swipeApiPage,setSwipeApiPage]=useState(0); const [swipeHasMore,setSwipeHasMore]=useState(true); const [swipeLoading,setSwipeLoading]=useState(false); const [ratings,setRatings]=useState(()=>readStore('animevault-ratings',{})); const [customLists,setCustomLists]=useState(()=>readStore('animevault-custom-lists',[])); const [profileName,setProfileName]=useState(()=>localStorage.getItem('animevault-profile-name')||'Anime-Fan'); const [currentYear]=useState(new Date().getFullYear()); const [clockNow,setClockNow]=useState(Date.now());
  const [minYear,setMinYear]=useState(''); const [maxYear,setMaxYear]=useState(''); const [minScore,setMinScore]=useState(''); const [maxEpisodes,setMaxEpisodes]=useState(''); const [sortBy,setSortBy]=useState('relevance'); const [advancedOpen,setAdvancedOpen]=useState(false);
  const [cloudUrl,setCloudUrl]=useState(()=>localStorage.getItem('animevault-cloud-url')||''); const [cloudKey,setCloudKey]=useState(()=>localStorage.getItem('animevault-cloud-key')||''); const [cloudEmail,setCloudEmail]=useState(''); const [cloudPassword,setCloudPassword]=useState(''); const [cloudSession,setCloudSession]=useState(()=>readStore('animevault-cloud-session',null)); const [cloudBusy,setCloudBusy]=useState(false); const [cloudMessage,setCloudMessage]=useState(''); const [friendProfiles,setFriendProfiles]=useState(()=>readStore('animevault-friends',[])); const [friendLink,setFriendLink]=useState('');
  useEffect(()=>{const timer=setInterval(()=>setClockNow(Date.now()),60000);return()=>clearInterval(timer);},[]);
  useEffect(()=>{writeStore('animevault-list',watchlist);},[watchlist]);
  useEffect(()=>writeStore('animevault-liked',likedIds),[likedIds]);
  useEffect(()=>writeStore('animevault-disliked',dislikedIds),[dislikedIds]);
  useEffect(()=>writeStore('animevault-ratings',ratings),[ratings]);
  useEffect(()=>writeStore('animevault-custom-lists',customLists),[customLists]);
  useEffect(()=>{try{localStorage.setItem('animevault-profile-name',profileName);}catch{}},[profileName]);
  useEffect(()=>{try{localStorage.setItem('animevault-cloud-url',cloudUrl.trim());localStorage.setItem('animevault-cloud-key',cloudKey.trim());}catch{}},[cloudUrl,cloudKey]);
  useEffect(()=>writeStore('animevault-cloud-session',cloudSession),[cloudSession]);
  useEffect(()=>writeStore('animevault-friends',friendProfiles),[friendProfiles]);
  useEffect(()=>{
    let cancelled = false;
    const titleKey = a => (a.title_english || a.title || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    const applyCovers = map => {
      const enrich = a => {
        const cover = map[a.mal_id] || map[`title:${titleKey(a)}`];
        if (!cover) return a;
        return { ...a, images: { jpg: { ...(a.images?.jpg || {}), image_url: cover, large_image_url: cover } } };
      };
      // Update the source catalog objects too, so later offline pagination keeps the real covers.
      [...starter, ...offlineCatalog].forEach(item => {
        const cover = map[item.mal_id] || map[`title:${titleKey(item)}`];
        if (cover) item.images = { jpg: { ...(item.images?.jpg || {}), image_url: cover, large_image_url: cover } };
      });
      setAnime(old => old.map(enrich));
      setHomeCatalog(old => old.map(enrich));
      setSelected(old => old ? enrich(old) : old);
      setWatchlist(old => Object.fromEntries(Object.entries(old).map(([id, entry]) => [id, { ...entry, anime: enrich(entry.anime) }])));
    };
    try {
      const cached = JSON.parse(localStorage.getItem('animevault-poster-cache') || '{}');
      if (Object.keys(cached).length) applyCovers(cached);
    } catch {}
    (async () => {
      try {
        const ids = [...new Set([...starter, ...offlineCatalog].map(a => Number(a.mal_id)).filter(id => Number.isInteger(id) && id > 0))];
        const covers = {};
        // Query smaller ID batches so the API returns a cover for the entire local catalogue,
        // not just the first 150 matches. This happens on page load, before a card is clicked.
        for (let start = 0; start < ids.length; start += 35) {
          if (cancelled) return;
          const batch = ids.slice(start, start + 35);
          const query = `query ($ids: [Int]) { Page(page: 1, perPage: 50) { media(type: ANIME, idMal_in: $ids, isAdult: false) { idMal title { romaji english } coverImage { large extraLarge } } } }`;
          try {
            const data = await aniListRequest(query, { ids: batch });
            for (const item of (data.Page?.media || [])) {
              const cover = item.coverImage?.extraLarge || item.coverImage?.large;
              if (cover && item.idMal) covers[item.idMal] = cover;
              if (cover) {
                const key = (item.title?.english || item.title?.romaji || '').toLowerCase().replace(/[^a-z0-9]/g, '');
                if (key) covers[`title:${key}`] = cover;
              }
            }
          } catch { /* Keep going: one failed batch shouldn't block the other posters. */ }
          if (start + 35 < ids.length) await new Promise(resolve => setTimeout(resolve, 180));
        }
        if (cancelled || !Object.keys(covers).length) return;
        applyCovers(covers);
        try { localStorage.setItem('animevault-poster-cache', JSON.stringify({ ...JSON.parse(localStorage.getItem('animevault-poster-cache') || '{}'), ...covers })); } catch {}
      } catch { /* cards remain usable; an individual title can still be enriched when opened */ }
    })();
    return () => { cancelled = true; };
  }, []);
  useEffect(()=>{
    if (!selected) return;
    const currentCover = selected.images?.jpg?.large_image_url || selected.images?.jpg?.image_url || '';
    if (currentCover && !currentCover.startsWith('data:image/svg+xml')) return;
    let cancelled = false;
    (async()=>{
      try {
        const data = await aniListRequest(`query ($search: String) { Media(search: $search, type: ANIME, isAdult: false) { id idMal title { romaji english } coverImage { large extraLarge } episodes averageScore genres description startDate { year } } }`, { search: selected.title_english || selected.title });
        if (cancelled || !data.Media) return;
        const found = normalizeAniList(data.Media);
        const key = (selected.title_english || selected.title || '').toLowerCase().replace(/[^a-z0-9]/g, '');
        const foundKey = (found.title_english || found.title || '').toLowerCase().replace(/[^a-z0-9]/g, '');
        if (!found.images?.jpg?.large_image_url || (key && foundKey && !key.includes(foundKey) && !foundKey.includes(key))) return;
        const cover = found.images.jpg.large_image_url;
        const patch = a => ((a.mal_id === selected.mal_id || (a.title_english || a.title || '').toLowerCase().replace(/[^a-z0-9]/g, '') === key) ? { ...a, images: { jpg: { ...(a.images?.jpg || {}), image_url: cover, large_image_url: cover } } } : a);
        setSelected(old => old ? patch(old) : old); setAnime(old => old.map(patch)); setHomeCatalog(old => old.map(patch));
        setWatchlist(old => Object.fromEntries(Object.entries(old).map(([id, entry]) => [id, { ...entry, anime: patch(entry.anime) }])));
        try { const cache = JSON.parse(localStorage.getItem('animevault-poster-cache') || '{}'); cache[selected.mal_id] = cover; cache[`title:${key}`] = cover; localStorage.setItem('animevault-poster-cache', JSON.stringify(cache)); } catch {}
      } catch {}
    })();
    return ()=>{cancelled=true;};
  }, [selected?.mal_id]);
  useEffect(()=>{
    let cancelled = false;
    setRelatedAnime([]);
    if (!selected) return;
    (async () => {
      try {
        const query = `query ($search: String) { Media(search: $search, type: ANIME, isAdult: false) { relations { edges { relationType(version: 2) node { id idMal type format status title { romaji english } coverImage { large extraLarge } episodes averageScore genres description startDate { year } } } } } }`;
        const data = await aniListRequest(query, { search: selected.title_english || selected.title });
        const edges = data.Media?.relations?.edges || [];
        const related = edges.filter(edge => edge.node?.type === 'ANIME' && ['PREQUEL','SEQUEL','SIDE_STORY','PARENT','SUMMARY'].includes(edge.relationType)).map(edge => ({ ...normalizeAniList(edge.node), relationType: edge.relationType }));
        if (!cancelled) setRelatedAnime(related.slice(0, 8));
      } catch { if (!cancelled) setRelatedAnime([]); }
    })();
    return () => { cancelled = true; };
  }, [selected?.mal_id]);
  useEffect(()=>{
    let cancelled = false;
    try {
      const cached = JSON.parse(localStorage.getItem('animevault-trending-cache-v3') || 'null');
      if (cached?.items?.length) setHomeTrending(cached.items);
      const fresh = cached?.savedAt && Date.now() - cached.savedAt < 6 * 60 * 60 * 1000;
      if (fresh) return () => { cancelled = true; };
    } catch {}
    (async () => {
      try {
        const items = await fetchAniListTrending();
        if (!cancelled && items.length) {
          setHomeTrending(items);
          try { localStorage.setItem('animevault-trending-cache-v3', JSON.stringify({ items, savedAt: Date.now() })); } catch {}
        }
      } catch { /* Keep cached/live catalogue data if the trend service is unavailable. */ }
    })();
    return () => { cancelled = true; };
  }, []);
  useEffect(()=>{
    let cancelled = false;
    const mergeUnique = (list) => {
      const ids = new Set(); const titles = new Set();
      return list.filter(item => {
        const id = item.mal_id;
        const title = (item.title_english || item.title || '').toLowerCase().replace(/[^a-z0-9]/g, '');
        if ((id && ids.has(id)) || (title && titles.has(title))) return false;
        if (id) ids.add(id); if (title) titles.add(title); return true;
      });
    };
    try {
      const cached = JSON.parse(localStorage.getItem('animevault-catalog') || '[]');
      if (Array.isArray(cached) && cached.length) setHomeCatalog(mergeUnique([...starter, ...offlineCatalog, ...cached]));
    } catch {}
    (async () => {
      const collected = [];
      for (const pageNo of [1, 2]) {
        try {
          if (pageNo > 1) await new Promise(resolve => setTimeout(resolve, 1200));
          const result = await apiGet(`${API}/top/anime?page=${pageNo}&limit=25&sfw=true`);
          collected.push(...(result.data || []));
        } catch { /* offline catalogue remains usable */ }
      }
      if (!cancelled && collected.length) {
        const unique = mergeUnique([...starter, ...offlineCatalog, ...collected]);
        setHomeCatalog(unique);
        try { localStorage.setItem('animevault-catalog', JSON.stringify(collected)); } catch {}
      }
    })();
    return () => { cancelled = true; };
  },[]);
  useEffect(()=>{
    if (page === 'discover' && !discoverInitialized.current) {
      discoverInitialized.current = true;
      if (query.trim()) searchAnime();
      else {
        setSearchMode('top'); setApiPage(1); setAnime(offlineCatalog.slice(0,24)); setHasMore(true);
        fetchTop(1, false);
      }
    }
  },[page]);
  const notify=(s)=>{setToast(s);setTimeout(()=>setToast(''),2200)};
  async function fetchTop(page=1,append=false){
    if (loading) return;
    setLoading(true); setError(''); setSearchMode('top'); setGenre('Alle'); setStatus('Alle');
    const localPage = offlineCatalog.slice((page-1)*24, page*24);
    if (!append) { setAnime(localPage.length ? localPage : offlineCatalog.slice(0,24)); setApiPage(1); setHasMore(true); }
    try {
      // AniList has a much larger catalogue than the static starter list; browse 50 per page.
      const live = await fetchAniListPage(page);
      const online = live.data || [];
      if (online.length) {
        setAnime(old=>{
          const merged = append ? [...old, ...online] : [...online, ...offlineCatalog.filter(x=>!online.some(y=>y.mal_id===x.mal_id))];
          const ids=new Set(); const titles=new Set();
          return merged.filter(a=>{const t=(a.title_english||a.title||'').toLowerCase().replace(/[^a-z0-9]/g,''); if((a.mal_id && ids.has(a.mal_id))||titles.has(t))return false;if(a.mal_id)ids.add(a.mal_id);titles.add(t);return true;});
        });
        setApiPage(page); setHasMore(Boolean(live.hasNextPage));
        try { localStorage.setItem('animevault-catalog', JSON.stringify(online.slice(0,500))); } catch {}
        return;
      }
      throw new Error('AniList returned no results');
    } catch {
      try {
        const j = await apiGet(`${API}/top/anime?page=${page}&limit=24&sfw=true`);
        const online = j.data || [];
        if (online.length) {
          setAnime(old=>{ const merged=append?[...old,...online]:[...online,...offlineCatalog.filter(x=>!online.some(y=>y.mal_id===x.mal_id))]; const ids=new Set(); return merged.filter(a=>{if(ids.has(a.mal_id))return false;ids.add(a.mal_id);return true;}); });
          setApiPage(page); setHasMore(Boolean(j.pagination?.has_next_page));
        } else throw new Error('No results');
      } catch {
        setError('Live-Datenbanken sind gerade nicht erreichbar. Dein Offline-Katalog bleibt verfügbar.');
        if (!append) { setAnime(offlineCatalog.slice(0,24)); setApiPage(1); setHasMore(offlineCatalog.length>24); }
        else { setApiPage(page); setHasMore(offlineCatalog.slice(page*24,(page+1)*24).length>0); }
      }
    } finally { setLoading(false); }
  }
  async function searchAnime(e, termOverride){
    e?.preventDefault();
    discoverInitialized.current = true;
    const term=(termOverride ?? query).trim();
    if(termOverride!==undefined)setQuery(term);
    setPage('discover'); setGenre('Alle'); setStatus('Alle'); setSearchMode(term?'search':'top'); setApiPage(1); setError('');
    if(!term){ fetchTop(1,false); return; }
    const local = [...homeCatalog, ...offlineCatalog, ...starter].filter((a,i,all)=>all.findIndex(x=>x.mal_id===a.mal_id)===i && `${a.title||''} ${a.title_english||''}`.toLowerCase().includes(term.toLowerCase()));
    setAnime(local); setHasMore(true); setLoading(true);
    try {
      const live = await fetchAniListPage(1, term);
      const online = live.data || [];
      const merged=[...online,...local].filter((a,i,all)=>all.findIndex(x=>{
        const xTitle=(x.title_english||x.title||'').toLowerCase().replace(/[^a-z0-9]/g,'');
        const aTitle=(a.title_english||a.title||'').toLowerCase().replace(/[^a-z0-9]/g,'');
        return (x.mal_id && x.mal_id===a.mal_id) || (xTitle && xTitle===aTitle);
      })===i);
      setAnime(merged); setHasMore(Boolean(live.hasNextPage) || local.length>24); setApiPage(1);
      try { localStorage.setItem('animevault-catalog', JSON.stringify([...online,...JSON.parse(localStorage.getItem('animevault-catalog')||'[]')].filter((a,i,all)=>all.findIndex(x=>x.mal_id===a.mal_id)===i).slice(0,500))); } catch {}
      if(!merged.length) setError(`Keine Treffer für „${term}“. Prüfe die Schreibweise oder versuche einen anderen Titel.`);
    } catch {
      try {
        const j = await apiGet(`${API}/anime?q=${encodeURIComponent(term)}&page=1&limit=24&sfw=true&order_by=popularity`);
        const online = j.data || [];
        const merged=[...online,...local].filter((a,i,all)=>all.findIndex(x=>x.mal_id===a.mal_id)===i);
        setAnime(merged); setHasMore(Boolean(j.pagination?.has_next_page) || local.length>24); setApiPage(1);
        if(!merged.length) setError(`Keine Treffer für „${term}“.`);
      } catch {
        setAnime(local); setHasMore(local.length>24); setApiPage(1);
        setError(local.length ? 'Live-Suche nicht erreichbar – passende Titel aus dem Offline-Katalog werden angezeigt.' : `Keine lokalen Treffer für „${term}“. Beide Live-Datenquellen sind gerade nicht erreichbar.`);
      }
    } finally { setLoading(false); }
  }
  async function loadMore(){
    if(loading||!hasMore)return;
    const next=apiPage+1; setLoading(true); setError('');
    const localSource = searchMode==='search' && query.trim()
      ? [...homeCatalog,...offlineCatalog,...starter].filter((a,i,all)=>all.findIndex(x=>x.mal_id===a.mal_id)===i && `${a.title||''} ${a.title_english||''}`.toLowerCase().includes(query.trim().toLowerCase()))
      : offlineCatalog;
    const localAdditions = localSource.slice(anime.length, anime.length+24);
    if (localAdditions.length) {
      setAnime(old=>{const ids=new Set(old.map(a=>a.mal_id));return [...old,...localAdditions.filter(a=>!ids.has(a.mal_id))];});
      setApiPage(next); setHasMore(localSource.length > anime.length + localAdditions.length);
      setLoading(false);
      return;
    }
    try {
      const live=await fetchAniListPage(next, searchMode==='search' ? query.trim() : '');
      const additions=live.data.filter(a=>!anime.some(x=>{
        const xt=(x.title_english||x.title||'').toLowerCase().replace(/[^a-z0-9]/g,'');
        const at=(a.title_english||a.title||'').toLowerCase().replace(/[^a-z0-9]/g,'');
        return (x.mal_id && x.mal_id===a.mal_id) || (xt && xt===at);
      }));
      setAnime(old=>[...old,...additions]); setApiPage(next); setHasMore(Boolean(live.hasNextPage));
      if (!additions.length && live.hasNextPage) setError('Auf dieser Seite gab es keine neuen Titel. Lade die nächste Seite erneut.');
      try { localStorage.setItem('animevault-catalog', JSON.stringify([...live.data,...JSON.parse(localStorage.getItem('animevault-catalog')||'[]')].filter((a,i,all)=>all.findIndex(x=>x.mal_id===a.mal_id)===i).slice(0,500))); } catch {}
    } catch {
      try {
        const url=searchMode==='search'&&query.trim()?`${API}/anime?q=${encodeURIComponent(query.trim())}&page=${next}&limit=24&sfw=true&order_by=popularity`:`${API}/top/anime?page=${next}&limit=24&sfw=true`;
        const j=await apiGet(url);
        const additions=(j.data||[]).filter(a=>!anime.some(x=>x.mal_id===a.mal_id));
        setAnime(old=>[...old,...additions]); setApiPage(next); setHasMore(Boolean(j.pagination?.has_next_page));
        if (!additions.length && j.pagination?.has_next_page) setError('Keine neuen Titel auf dieser Seite. Versuche es erneut.');
      } catch { setHasMore(false); setError('Der Live-Katalog ist gerade nicht erreichbar. Deine gespeicherten Anime bleiben erhalten.'); }
    } finally { setLoading(false); }
  }
  const shiftHome=(key,delta,list)=>setHomeIndices(old=>({...old,[key]:(old[key]+delta+list.length)%list.length}));
  const featuredId = 16498; // Keep the hero cover out of every carousel.
  const allHomeUnique = homeCatalog.filter((a,i,all)=>all.findIndex(x=>x.mal_id===a.mal_id && (x.title_english||x.title)===(a.title_english||a.title))===i && all.findIndex(x=>(x.title_english||x.title||'').toLowerCase().replace(/[^a-z0-9]/g,'')===(a.title_english||a.title||'').toLowerCase().replace(/[^a-z0-9]/g,''))===i);
  const withoutFeatured = allHomeUnique.filter(a => a.mal_id !== featuredId);
  const homePopular = withoutFeatured.slice(0, 50);
  const titleKey = a => (a.title_english || a.title || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  const popularIds = new Set(homePopular.map(a => a.mal_id));
  const popularTitles = new Set(homePopular.map(titleKey));
  const homeAction = withoutFeatured.filter(a => !popularIds.has(a.mal_id) && !popularTitles.has(titleKey(a)) && (a.genres||[]).some(g=>['Action','Adventure'].includes(g.name))).slice(0, 50);
  const actionIds = new Set([...popularIds, ...homeAction.map(a => a.mal_id)]);
  const actionTitles = new Set([...popularTitles, ...homeAction.map(titleKey)]);
  const homeFantasy = withoutFeatured.filter(a => !actionIds.has(a.mal_id) && !actionTitles.has(titleKey(a)) && (a.genres||[]).some(g=>['Fantasy','Supernatural'].includes(g.name))).slice(0, 50);
  const carouselWindow=(items,index,count=5)=>items.length ? Array.from({length:Math.min(count,items.length)},(_,i)=>items[(index+i)%items.length]) : [];
  const genres=useMemo(()=>['Alle',...new Set(anime.flatMap(a=>(a.genres||[]).map(g=>g.name)))].slice(0,12),[anime]);
  const filtered=useMemo(()=>{const result=anime.filter(a=>{const q=query.toLowerCase();const matches=searchMode==='search'||!q||a.title?.toLowerCase().includes(q)||(a.title_english||'').toLowerCase().includes(q);const g=genre==='Alle'||(a.genres||[]).some(x=>x.name===genre);const s=status==='Alle'||watchlist[a.mal_id]?.status===status;const dub=dubFilter==='Alle'||(dubFilter==='Deutsch bekannt'&&knownGermanDubs.has(normalizeTitleKey(a.title_english||a.title)));const y=Number(a.year||a.aired?.prop?.from?.year||0);const score=Number(a.score||0);const eps=Number(a.episodes||0);return matches&&g&&s&&dub&&(!minYear||y>=Number(minYear))&&(!maxYear||y<=Number(maxYear))&&(!minScore||score>=Number(minScore))&&(!maxEpisodes||eps>0&&eps<=Number(maxEpisodes));});return result.sort((a,b)=>sortBy==='title'?(a.title_english||a.title).localeCompare(b.title_english||b.title):sortBy==='year'?(b.year||0)-(a.year||0):sortBy==='episodes'?(a.episodes||9999)-(b.episodes||9999):sortBy==='score'?(b.score||0)-(a.score||0):sortBy==='relevance'?(Number(b.score||0)-Number(a.score||0)):0);},[anime,query,genre,status,dubFilter,watchlist,searchMode,minYear,maxYear,minScore,maxEpisodes,sortBy,tasteGenres,homeTrending,currentYear]);
  const add=(a,s='Geplant')=>{setWatchlist(p=>({...p,[a.mal_id]:{...p[a.mal_id],anime:a,status:s,progress:p[a.mal_id]?.progress||0,...(s==='Gesehen'?{completedAt:p[a.mal_id]?.completedAt||new Date().toISOString()}: {})}}));notify(s==='Gesehen'?'Als gesehen markiert':'Zu deiner Liste hinzugefügt');};
  const update=(id,changes)=>setWatchlist(p=>({...p,[id]:{...p[id],...changes,...(changes.status==='Gesehen'?{completedAt:p[id]?.completedAt||new Date().toISOString()}:changes.status?{completedAt:null}:{})}}));
  const remove=(id)=>{setWatchlist(p=>{const n={...p};delete n[id];return n;});notify('Aus deiner Liste entfernt');};
  const saved=Object.values(watchlist); const watched=saved.filter(x=>x.status==='Gesehen'); const watching=saved.filter(x=>x.status==='Schaue ich'); const planned=saved.filter(x=>x.status==='Geplant');
  const exportWatchlist=()=>{try{const blob=new Blob([JSON.stringify({app:'AnimeVault',version:2,exportedAt:new Date().toISOString(),watchlist},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='animevault-watchlist-backup.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);notify('Backup wurde erstellt');}catch{notify('Backup konnte nicht erstellt werden');}};
  const importWatchlist=async e=>{const file=e.target.files?.[0];if(!file)return;try{const data=JSON.parse(await file.text());const imported=data.watchlist||data;if(!imported||typeof imported!=='object'||Array.isArray(imported))throw new Error('Ungültige Datei');const merged={...watchlist,...imported};setWatchlist(merged);notify('Backup wurde importiert');}catch{notify('Datei ist kein gültiges AnimeVault-Backup');}finally{e.target.value='';}};
  const allRecommendationPool = useMemo(()=>{const all=[...homeTrending,...homeCatalog,...anime,...offlineCatalog,...starter];const seen=new Set();return all.filter(a=>{const key=titleKey(a)||String(a.mal_id);if(seen.has(key))return false;seen.add(key);return true;});},[homeTrending,homeCatalog,anime]);
  const tasteGenres = useMemo(()=>{const scores={};for(const id of likedIds){const a=allRecommendationPool.find(x=>String(x.mal_id)===String(id))||watchlist[id]?.anime;if(a)(a.genres||[]).forEach(g=>scores[g.name]=(scores[g.name]||0)+3);}for(const item of watched){(item.anime.genres||[]).forEach(g=>scores[g.name]=(scores[g.name]||0)+2);}for(const item of saved.filter(x=>x.status==='Geplant'||x.status==='Schaue ich')){(item.anime.genres||[]).forEach(g=>scores[g.name]=(scores[g.name]||0)+1);}for(const [id,rating] of Object.entries(ratings)){const a=allRecommendationPool.find(x=>String(x.mal_id)===String(id))||watchlist[id]?.anime;if(a&&rating>=3)(a.genres||[]).forEach(g=>scores[g.name]=(scores[g.name]||0)+(rating-2));}for(const id of dislikedIds){const a=allRecommendationPool.find(x=>String(x.mal_id)===String(id));if(a)(a.genres||[]).forEach(g=>scores[g.name]=(scores[g.name]||0)-2);}return scores;},[likedIds,dislikedIds,allRecommendationPool,watched,watchlist,saved,ratings]);
  const recommendationScore = a => {const gs=(a.genres||[]).reduce((sum,g)=>sum+(tasteGenres[g.name]||0),0);const score=Number(a.score||a.averageScore||0);const trend=homeTrending.some(x=>String(x.mal_id)===String(a.mal_id))?1.5:0;const fresh=a.year&&a.year>=currentYear-2?0.4:0;return gs+score*.22+trend+fresh;};
  const swipePool = useMemo(()=>allRecommendationPool.filter(a=>!likedIds.includes(String(a.mal_id))&&!likedIds.includes(a.mal_id)&&!dislikedIds.includes(String(a.mal_id))&&!dislikedIds.includes(a.mal_id)&&watchlist[a.mal_id]?.status!=='Gesehen').sort((a,b)=>recommendationScore(b)-recommendationScore(a)),[allRecommendationPool,likedIds,dislikedIds,watchlist,tasteGenres,homeTrending,currentYear]);
  const loadMoreSwipe=async()=>{if(swipeLoading||!swipeHasMore)return;setSwipeLoading(true);try{const next=swipeApiPage+1;const live=await fetchAniListPage(next);setHomeCatalog(old=>{const ids=new Set(old.map(a=>String(a.mal_id)));const titles=new Set(old.map(a=>titleKey(a)));return [...old,...live.data.filter(a=>!ids.has(String(a.mal_id))&&!titles.has(titleKey(a)))];});setSwipeApiPage(next);setSwipeHasMore(Boolean(live.hasNextPage));}catch{setSwipeHasMore(false);notify('Mehr Swipe-Anime konnten gerade nicht geladen werden.');}finally{setSwipeLoading(false);}};
  useEffect(()=>{if(page==='swipe'&&swipePool.length<3&&swipeHasMore&&!swipeLoading)loadMoreSwipe();},[page,swipePool.length,swipeHasMore,swipeLoading]);
  const swipeAction=(a,action)=>{if(!a)return;const id=String(a.mal_id);setSwipeHistory(old=>[...old,{id,action,wasSaved:Boolean(watchlist[a.mal_id]),oldEntry:watchlist[a.mal_id]||null}].slice(-30));if(action==='like'){setLikedIds(old=>old.includes(id)?old:[...old,id]);setDislikedIds(old=>old.filter(x=>String(x)!==id));setWatchlist(old=>({...old,[a.mal_id]:{...(old[a.mal_id]||{}),anime:a,status:old[a.mal_id]?.status||'Geplant',progress:old[a.mal_id]?.progress||0}}));notify('Gefällt dir – gespeichert!');}else{setDislikedIds(old=>old.includes(id)?old:[...old,id]);setLikedIds(old=>old.filter(x=>String(x)!==id));notify('Wird künftig seltener empfohlen');}};
  const undoSwipe=()=>{const last=swipeHistory[swipeHistory.length-1];if(!last){notify('Nichts zum Rückgängigmachen');return;}setSwipeHistory(old=>old.slice(0,-1));if(last.action==='like')setLikedIds(old=>old.filter(x=>String(x)!==last.id));if(last.action==='dislike')setDislikedIds(old=>old.filter(x=>String(x)!==last.id));setWatchlist(old=>{const next={...old};if(last.wasSaved)next[last.id]=last.oldEntry;else if(last.action==='like')delete next[last.id];return next;});notify('Letzter Swipe rückgängig');};
  const setRating=(a,value)=>{const id=String(a.mal_id);setRatings(old=>({...old,[a.mal_id]:value}));if(value>=4){setLikedIds(old=>old.includes(id)?old:[...old,id]);setDislikedIds(old=>old.filter(x=>String(x)!==id));}else{setLikedIds(old=>old.filter(x=>String(x)!==id));if(value<=2)setDislikedIds(old=>old.includes(id)?old:[...old,id]);else setDislikedIds(old=>old.filter(x=>String(x)!==id));}};
  const cloudRequest=async(path,options={})=>{const base=cloudUrl.trim().replace(/\/$/,'');const key=cloudKey.trim();if(!base||!key)throw new Error('Bitte zuerst Supabase-URL und Anon-Key eintragen.');const response=await fetch(`${base}${path}`,{...options,headers:{apikey:key,'Content-Type':'application/json',...(options.headers||{})}});const body=await response.json().catch(()=>null);if(!response.ok)throw new Error(body?.msg||body?.message||body?.error_description||body?.error||`Cloud-Fehler ${response.status}`);return body;};
  const cloudAuth=async(mode)=>{setCloudBusy(true);setCloudMessage('');try{const body=await cloudRequest(mode==='signup'?'/auth/v1/signup':'/auth/v1/token?grant_type=password',{method:'POST',body:JSON.stringify({email:cloudEmail.trim(),password:cloudPassword})});if(!body.access_token){setCloudMessage('Konto erstellt. Falls E-Mail-Bestätigung aktiv ist, bestätige zuerst deine E-Mail und melde dich danach an.');return;}const session={access_token:body.access_token,refresh_token:body.refresh_token,user:{id:body.user?.id,email:body.user?.email}};setCloudSession(session);setCloudMessage(`Angemeldet als ${session.user.email}. Du kannst jetzt synchronisieren.`);setCloudPassword('');}catch(e){setCloudMessage(e.message||'Anmeldung fehlgeschlagen. Prüfe URL, Key und Zugangsdaten.');}finally{setCloudBusy(false);}};
  const cloudLogout=()=>{setCloudSession(null);setCloudMessage('Abgemeldet. Deine lokalen Daten bleiben erhalten.');};
  const cloudSync=async(mode)=>{if(!cloudSession?.access_token||!cloudSession?.user?.id){setCloudMessage('Melde dich zuerst mit deinem Cloud-Konto an.');return;}setCloudBusy(true);setCloudMessage('');try{const headers={Authorization:`Bearer ${cloudSession.access_token}`,Prefer:'resolution=merge-duplicates,return=minimal'};if(mode==='upload'){const payload={watchlist,likedIds,dislikedIds,ratings,customLists,profileName,version:3,syncedAt:new Date().toISOString()};await cloudRequest('/rest/v1/animevault_sync?on_conflict=user_id',{method:'POST',headers,body:JSON.stringify({user_id:cloudSession.user.id,payload,updated_at:new Date().toISOString()})});setCloudMessage('Cloud-Backup hochgeladen. Auf anderen Geräten kannst du es wiederherstellen.');}else{const rows=await cloudRequest(`/rest/v1/animevault_sync?user_id=eq.${encodeURIComponent(cloudSession.user.id)}&select=payload,updated_at&limit=1`,{headers:{Authorization:`Bearer ${cloudSession.access_token}`}});if(!rows?.length)throw new Error('Noch kein Cloud-Backup vorhanden. Lade auf deinem ersten Gerät zuerst hoch.');const d=rows[0].payload||{};if(d.watchlist)setWatchlist(d.watchlist);if(d.likedIds)setLikedIds(d.likedIds);if(d.dislikedIds)setDislikedIds(d.dislikedIds);if(d.ratings)setRatings(d.ratings);if(d.customLists)setCustomLists(d.customLists);if(d.profileName)setProfileName(d.profileName);setCloudMessage(`Cloud-Backup vom ${new Date(rows[0].updated_at).toLocaleString('de-DE')} wiederhergestellt.`);}}catch(e){setCloudMessage(`${e.message||'Synchronisierung fehlgeschlagen'} Prüfe auch die SQL-Tabelle und RLS-Regeln in der Anleitung.`);}finally{setCloudBusy(false);}};
  const exportProfileLink=async()=>{const payload={name:profileName,year:currentYear,completed:watched.length,watching:watching.length,likes:likedIds.length,favorites:saved.filter(x=>likedIds.includes(String(x.anime.mal_id))).slice(0,20).map(x=>({title:x.anime.title_english||x.anime.title,rating:ratings[x.anime.mal_id]||null,year:x.anime.year||null}))};const encoded=btoa(unescape(encodeURIComponent(JSON.stringify(payload))));const url=`${location.origin}${location.pathname}#share=${encoded}`;try{await navigator.clipboard.writeText(url);notify('Profil-Link kopiert!');}catch{window.prompt('Kopiere deinen Profil-Link:',url);}};
  const addFriendProfile=()=>{try{const match=friendLink.match(/#share=([^&]+)/);if(!match)throw new Error('Füge einen vollständigen AnimeVault-Profil-Link mit #share= ein.');const data=JSON.parse(decodeURIComponent(escape(atob(match[1]))));if(!data?.name)throw new Error('Der Link enthält kein gültiges Profil.');const id=`${data.name}-${data.year||''}-${data.completed||0}-${data.likes||0}`;setFriendProfiles(old=>old.some(x=>x.id===id)?old:[...old,{...data,id,addedAt:new Date().toISOString()}]);setFriendLink('');notify(`${data.name} zu deinen Freunden hinzugefügt`);}catch(e){notify(e.message||'Profil-Link konnte nicht gelesen werden');}};
  const createCustomList=()=>{const name=window.prompt('Wie soll deine Anime-Liste heißen?');if(!name?.trim())return;setCustomLists(old=>[...old,{id:`list-${Date.now()}`,name:name.trim(),ids:[],createdAt:new Date().toISOString()}]);notify('Liste erstellt');};
  const toggleCustomList=(listId,animeId)=>setCustomLists(old=>old.map(list=>list.id===listId?{...list,ids:list.ids.includes(String(animeId))?list.ids.filter(id=>id!==String(animeId)):[...list.ids,String(animeId)]}:list));
  const completedThisYear=watched.filter(item=>item.completedAt&&new Date(item.completedAt).getFullYear()===currentYear);
  const hero=starter[1];
  return <div className="app"><aside className="sidebar"><div className="brand"><div className="brand-icon"><Sparkles size={21}/></div><span>Anime<span className="accent">Vault</span></span></div><div className="nav-label">MENÜ</div><nav>{navItems.map(({id,label,Icon})=><button key={id} className={`nav-btn ${page===id?'active':''}`} onClick={()=>setPage(id)}><Icon size={18}/>{label}{id==='list'&&saved.length>0&&<span className="nav-count">{saved.length}</span>}</button>)}</nav><div className="sidebar-bottom"><div className="mini-card"><div className="mini-icon"><Heart size={17}/></div><b>Dein Anime-Universum</b><p>Finde deinen nächsten Lieblingsanime.</p><button onClick={()=>setPage('discover')}>Anime entdecken <span>↗</span></button></div><div className="profile"><div className="avatar">{profileName.trim().charAt(0).toUpperCase()||'A'}</div><div><b>{profileName}</b><small>Deine Sammlung</small></div><button title="Einstellungen" onClick={()=>setPage('settings')}><Settings size={17}/></button></div></div></aside>
  <main className="main"><header className="topbar"><div className="mobile-brand"><div className="brand-icon"><Sparkles size={19}/></div>Anime<span className="accent">Vault</span></div><div className="breadcrumb">Dein Anime-Universum <span>/</span> <b>{navItems.find(n=>n.id===page)?.label||'Einstellungen'}</b></div><form className="top-search" onSubmit={searchAnime}><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Anime suchen..."/><kbd>↵</kbd></form><button className="top-avatar" onClick={()=>setPage('settings')}>A</button></header>
  {page==='home'&&!sharedProfile&&<><section className="welcome"><div><div className="eyebrow"><span className="live-dot"/> DEIN PERSÖNLICHER ANIME-TRACKER</div><h1>Dein nächstes<br/><span>Anime-Abenteuer</span> wartet.</h1><p>Entdecke neue Welten, tracke deinen Fortschritt und behalte alle Anime im Blick.</p><div className="hero-actions"><button className="primary" onClick={()=>setPage('discover')}><Compass size={17}/> Anime entdecken</button><button className="secondary" onClick={()=>setPage('list')}><Bookmark size={17}/> Meine Liste <span className="btn-count">{saved.length}</span></button></div></div><div className="hero-art"><div className="orb orb-one"/><div className="orb orb-two"/><div className="hero-poster"><AnimeImage anime={hero} alt="Anime cover" loading="eager"/><div className="poster-shade"/><div className="poster-tag"><Flame size={13}/> FAN-FAVORIT</div><div className="poster-info"><span>JETZT ENTDECKEN</span><b>{hero.title_english||hero.title}</b><div><Star size={14} fill="currentColor"/> {hero.score||'—'} <span>•</span> {hero.year||'Anime'}</div></div></div><div className="floating-rating"><Star size={16} fill="currentColor"/><div><b>Top bewertet</b><small>Anime-Community</small></div></div></div></section>
  <section className="stats-grid"><Stat icon={<Bookmark/>} label="In deiner Liste" value={saved.length} foot="Deine Sammlung"/><Stat icon={<Play/>} label="Schaue ich" value={watching.length} foot="Aktuell dran"/><Stat icon={<Check/>} label="Abgeschlossen" value={watched.length} foot="Anime gesehen"/><Stat icon={<Clock3/>} label="Geplant" value={planned.length} foot="Für später"/></section>
  <section className="section personal-picks"><div className="section-heading"><div><div className="eyebrow"><Sparkles size={13}/> DEIN GESCHMACK</div><h2>Für <span>dich empfohlen</span></h2><p>Vorschläge aus deinen Likes, Bewertungen, Genres und deiner Watchlist.</p></div><button className="text-button" onClick={()=>setPage('swipe')}>Mehr entdecken →</button></div><div className="anime-grid home-carousel-grid">{allRecommendationPool.filter(a=>!saved.some(x=>String(x.anime.mal_id)===String(a.mal_id))&&!dislikedIds.some(id=>String(id)===String(a.mal_id))).sort((a,b)=>recommendationScore(b)-recommendationScore(a)).slice(0,5).map(a=><AnimeCard key={`for-you-${a.mal_id}`} anime={a} entry={watchlist[a.mal_id]} onOpen={()=>setSelected(a)} onAdd={()=>add(a)}/>)}</div></section>
  <section className="section home-row"><div className="section-heading"><div><div className="eyebrow"><span className="live-dot"/> LIVE-DATEN</div><h2>Aktuelle <span>Trends</span> <Flame size={19}/></h2><p>Bis zu 50 angesagte Anime – die Pfeile zeigen immer nur eine übersichtliche Auswahl. Live-Daten werden maximal sechs Stunden zwischengespeichert.</p></div><div className="carousel-controls"><button className="carousel-arrow" aria-label="Trends zurück" onClick={()=>shiftHome('trending',-1,homeTrending)} disabled={homeTrending.length<2}>‹</button><button className="carousel-arrow" aria-label="Trends weiter" onClick={()=>shiftHome('trending',1,homeTrending)} disabled={homeTrending.length<2}>›</button><button className="text-button" onClick={()=>{setPage('discover');setQuery('');fetchTop(1,false);}}>Alle entdecken <span>→</span></button></div></div>{homeTrending.length ? <div className="anime-grid home-carousel-grid">{carouselWindow(homeTrending,homeIndices.trending||0).map(a=><AnimeCard key={`trending-${a.mal_id}`} anime={a} entry={watchlist[a.mal_id]} onOpen={()=>setSelected(a)} onAdd={()=>add(a)}/>)}</div> : <p className="home-hint">Aktuelle Trends werden geladen. Für Live-Daten ist eine Internetverbindung nötig.</p>}</section>
  {homeTrending.some(a=>a.status==='RELEASING'||a.nextAiringEpisode) && <section className="section home-row"><div className="section-heading"><div><div className="eyebrow"><CalendarDays size={13}/> FOLGEN-UPDATE</div><h2>Läuft <span>aktuell</span></h2><p>Laufende Serien aus den Live-Daten. Termine werden angezeigt, wenn AniList sie bereitstellt.</p></div><div className="carousel-controls"><button className="carousel-arrow" aria-label="Laufende Anime zurück" onClick={()=>shiftHome('airing',-1,homeTrending.filter(a=>a.status==='RELEASING'||a.nextAiringEpisode))}>‹</button><button className="carousel-arrow" aria-label="Laufende Anime weiter" onClick={()=>shiftHome('airing',1,homeTrending.filter(a=>a.status==='RELEASING'||a.nextAiringEpisode))}>›</button></div></div><div className="anime-grid home-carousel-grid">{carouselWindow(homeTrending.filter(a=>a.status==='RELEASING'||a.nextAiringEpisode),homeIndices.airing||0).map(a=><AnimeCard key={`airing-${a.mal_id}`} anime={a} entry={watchlist[a.mal_id]} onOpen={()=>setSelected(a)} onAdd={()=>add(a)}/>)}</div></section>}
{[['popular','Beliebte Anime','Die beliebtesten Titel für deinen nächsten Binge.',homePopular],['action','Action & Abenteuer','Kämpfe, große Welten und starke Storys.',homeAction],['fantasy','Fantasy & Übernatürliches','Magie, Dämonen und andere Welten.',homeFantasy]].map(([key,title,desc,items])=><section className="section home-row" key={key}><div className="section-heading"><div><div className="eyebrow">ANIMEVAULT EMPFIEHLT</div><h2>{title} <span>✦</span></h2><p>{desc}</p></div><div className="carousel-controls"><button className="carousel-arrow" aria-label={`${title} zurück`} onClick={()=>shiftHome(key,-1,items)} disabled={items.length<2}>‹</button><button className="carousel-arrow" aria-label={`${title} weiter`} onClick={()=>shiftHome(key,1,items)} disabled={items.length<2}>›</button><button className="text-button" onClick={()=>{setPage('discover');setQuery('');}}>Alle entdecken <span>→</span></button></div></div><div className="anime-grid home-carousel-grid">{carouselWindow(items,homeIndices[key]||0).map(a=><AnimeCard key={`${key}-${a.mal_id}`} anime={a} entry={watchlist[a.mal_id]} onOpen={()=>setSelected(a)} onAdd={()=>add(a)}/>)}</div>{items.length===0&&<p className="home-hint">Diese Kategorie ist gerade leer. Prüfe deine Internetverbindung und lade die Seite neu.</p>}</section>)}</>}
  {page==='home'&&sharedProfile&&<section className="page-section shared-profile-page"><div className="page-title"><div className="eyebrow">GETEILTES ANIME-PROFIL</div><h1>Profil von {sharedProfile.name||'Anime-Fan'} <span>Anime-Recap</span></h1><p>Ein von einem AnimeVault-Nutzer geteilter Profil-Snapshot. Persönliche Daten und Watchlist bleiben privat.</p></div><div className="stats-grid stats-large"><Stat icon={<Check/>} label="Abgeschlossen" value={sharedProfile.completed??0} foot="Anime fertig geschaut"/><Stat icon={<Heart/>} label="Likes" value={sharedProfile.likes??0} foot="Geteilte Vorlieben"/><Stat icon={<Play/>} label="In Arbeit" value={sharedProfile.watching??0} foot="Anime in progress"/></div><h2 className="subhead">Geteilte Favoriten</h2>{sharedProfile.favorites?.length?<div className="shared-favorites">{sharedProfile.favorites.map((item,i)=><div key={`${item.title}-${i}`}><b>{item.title}</b><span>{item.year||'—'} · {item.rating?`${item.rating}/5 Sterne`:'Nicht bewertet'}</span></div>)}</div>:<p>Für dieses Profil wurden keine Favoriten geteilt.</p>}<button className="secondary" onClick={()=>{history.replaceState(null,'',location.pathname);setSharedProfile(null);}}>Zur eigenen AnimeVault-Startseite</button></section>}
  {page==='discover'&&<section className="page-section"><div className="page-title"><div className="eyebrow">FINDE DEINEN NÄCHSTEN FAVORITEN</div><h1>Anime <span>entdecken</span></h1><p>Such dich durch tausende Anime und speichere, was dich interessiert.</p></div><form className="big-search" onSubmit={searchAnime}><Search size={20}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Titel, z. B. Naruto, One Piece..."/><button className="primary">Suchen</button></form><div className="filters"><div className="filter-label"><SlidersHorizontal size={16}/> Filter</div><div className="chips">{genres.map(g=><button key={g} className={`chip ${genre===g?'chosen':''}`} onClick={()=>setGenre(g)}>{g}</button>)}</div><select value={status} onChange={e=>setStatus(e.target.value)}><option>Alle</option><option>Geplant</option><option>Schaue ich</option><option>Gesehen</option></select><select aria-label="Synchronisation filtern" value={dubFilter} onChange={e=>setDubFilter(e.target.value)}><option value="Alle">Alle Synchros</option><option value="Deutsch bekannt">Deutsche Synchro bekannt</option></select><button className="secondary advanced-toggle" onClick={()=>setAdvancedOpen(v=>!v)}><SlidersHorizontal size={15}/>{advancedOpen?"Weniger Filter":"Erweiterte Suche"}</button></div>{advancedOpen&&<div className="advanced-search-panel"><label>Ab Jahr<input type="number" min="1960" max="2100" value={minYear} onChange={e=>setMinYear(e.target.value)} placeholder="z. B. 2018"/></label><label>Bis Jahr<input type="number" min="1960" max="2100" value={maxYear} onChange={e=>setMaxYear(e.target.value)} placeholder="beliebig"/></label><label>Mind. Score<input type="number" min="0" max="10" step="0.1" value={minScore} onChange={e=>setMinScore(e.target.value)} placeholder="z. B. 8"/></label><label>Max. Folgen<input type="number" min="1" max="1000" value={maxEpisodes} onChange={e=>setMaxEpisodes(e.target.value)} placeholder="z. B. 24"/></label><label>Sortieren<select value={sortBy} onChange={e=>setSortBy(e.target.value)}><option value="relevance">Beliebteste zuerst</option><option value="score">Community-Score</option><option value="year">Neueste zuerst</option><option value="title">Titel A–Z</option><option value="episodes">Wenige Folgen zuerst</option></select></label><button className="text-button" onClick={()=>{setMinYear('');setMaxYear('');setMinScore('');setMaxEpisodes('');setSortBy('relevance');}}>Filter zurücksetzen</button></div>}{error&&<div className="notice">{error} <button className="notice-retry" onClick={()=>searchMode==='search'?searchAnime():fetchTop(1,false)}>Erneut versuchen</button></div>}{loading&&anime.length===0?<div className="loading"><div className="spinner"/>Anime werden geladen...</div>:<><div className="anime-grid discover-grid">{filtered.map(a=><AnimeCard key={a.mal_id} anime={a} entry={watchlist[a.mal_id]} onOpen={()=>setSelected(a)} onAdd={()=>add(a)}/>)}</div>{loading&&<div className="loading more-loading"><div className="spinner"/>Anime werden geladen …</div>}{!loading&&hasMore&&<div className="load-more-wrap"><button className="primary load-more" onClick={loadMore}>Mehr Anime laden <span>↓</span></button><p>Seite {apiPage} · Weitere Ergebnisse aus der Anime-Datenbank</p></div>}</>}{!loading&&!filtered.length&&!error&&<div className="empty"><Search size={28}/><h3>Keine Anime gefunden</h3><p>Ändere deine Suche oder entferne ein paar Filter.</p><button className="secondary" onClick={()=>{setQuery('');setGenre('Alle');setStatus('Alle');setDubFilter('Alle');}}>Filter zurücksetzen</button></div>}</section>}
  {page==='list'&&<section className="page-section"><div className="page-title"><div className="eyebrow">DEINE PERSÖNLICHE SAMMLUNG</div><h1>Meine <span>Liste</span></h1><p>Alles, was du schauen willst, gerade schaust oder schon gesehen hast.</p></div><div className="list-tabs"><div><span>{saved.length}</span> Anime gespeichert</div><button className="secondary" onClick={()=>setPage('discover')}><Plus size={16}/> Anime hinzufügen</button></div>{saved.length===0?<div className="empty"><Bookmark size={30}/><h3>Deine Liste ist noch leer</h3><p>Speichere Anime, damit du sie später wiederfindest.</p><button className="primary" onClick={()=>setPage('discover')}>Anime entdecken</button></div>:<div className="collection">{saved.map(item=><div className="collection-item" key={item.anime.mal_id}><AnimeImage anime={item.anime} alt=""/><div className="collection-info"><h3>{item.anime.title_english||item.anime.title}</h3><div className="muted-line">{item.anime.year||item.anime.aired?.prop?.from?.year||'—'} · {item.anime.episodes||'?'} Folgen · <Star size={13} fill="currentColor"/> {item.anime.score||'—'}</div><div className="progress-row"><span>Fortschritt</span><span>{item.progress||0} / {item.anime.episodes||'?'}</span></div><div className="progress"><div style={{width:`${item.anime.episodes?Math.min(100,(item.progress||0)/item.anime.episodes*100):0}%`}}/></div></div><div className="collection-controls"><select value={item.status} onChange={e=>update(item.anime.mal_id,{status:e.target.value})}><option>Geplant</option><option>Schaue ich</option><option>Gesehen</option></select><div className="progress-controls"><button onClick={()=>update(item.anime.mal_id,{progress:Math.max(0,(item.progress||0)-1)})}>−</button><button onClick={()=>update(item.anime.mal_id,{progress:Math.min(item.anime.episodes||999,(item.progress||0)+1)})}>+</button></div><button className="remove-btn" title="Entfernen" onClick={()=>remove(item.anime.mal_id)}><X size={17}/></button></div></div>)}</div>}</section>}
  {page==='swipe'&&<section className="page-section feature-page"><div className="page-title"><div className="eyebrow">DEIN GESCHMACK · LERNT MIT</div><h1>Swipe <span>Modus 2.0</span></h1><p>Kein Popup, kein Stopp. Likes landen automatisch in deiner Liste und trainieren deine Empfehlungen.</p></div><div className="taste-chips"><span>{likedIds.length} Likes</span><span>{dislikedIds.length} übersprungen</span><span>Top-Genres: {Object.entries(tasteGenres).filter(([,v])=>v>0).sort((a,b)=>b[1]-a[1]).slice(0,3).map(([g])=>g).join(', ')||'lernt deinen Geschmack'}</span></div>{swipePool.length? <div className="swipe-layout"><div className="swipe-card" key={swipePool[0].mal_id}><AnimeImage anime={swipePool[0]} alt={swipePool[0].title} loading="eager"/><div className="swipe-gradient"/><div className="swipe-info"><div className="eyebrow">PASST ZU DEINEM GESCHMACK</div><h2>{swipePool[0].title_english||swipePool[0].title}</h2><p>{swipePool[0].year||'Jahr unbekannt'} · {swipePool[0].episodes||'?'} Folgen · ★ {swipePool[0].score||'—'}</p><div className="detail-genres">{(swipePool[0].genres||[]).slice(0,4).map(g=><span key={g.name}>{g.name}</span>)}</div></div></div><div className="swipe-controls"><button className="swipe-no" onClick={()=>swipeAction(swipePool[0],'dislike')} aria-label="Überspringen"><X size={25}/></button><button className="swipe-undo" onClick={undoSwipe} disabled={!swipeHistory.length} aria-label="Rückgängig"><Undo2 size={19}/></button><button className="swipe-yes" onClick={()=>swipeAction(swipePool[0],'like')} aria-label="Gefällt mir"><Heart size={24} fill="currentColor"/></button></div><p className="swipe-hint">X = überspringen · ♥ = merken · ↶ = rückgängig</p></div>:swipeLoading?<div className="loading"><div className="spinner"/>Neue Anime werden geladen …</div>:<div className="empty"><Trophy size={30}/><h3>Du hast alle Vorschläge durch!</h3><p>Dein Geschmack wurde aktualisiert. Setze deine Auswahl zurück oder lade den Katalog im Entdecken-Bereich.</p><button className="primary" onClick={()=>{setDislikedIds([]);setLikedIds([]);setSwipeHistory([]);setSwipeHasMore(true);setSwipeApiPage(0);}}>Swipe-Auswahl zurücksetzen</button><button className="secondary" onClick={()=>setPage('discover')}>Katalog öffnen</button></div>}<div className="section-heading"><div><h2>Deine <span>Likes</span></h2><p>Deine zuletzt gelikten Anime – direkt gesammelt.</p></div><button className="secondary" onClick={()=>{const chosen=allRecommendationPool.filter(a=>likedIds.includes(String(a.mal_id)));chosen.forEach(a=>{if(!watchlist[a.mal_id])add(a);});notify(`${chosen.length} Likes geprüft`);}}>Alle Likes speichern</button></div><div className="anime-grid">{allRecommendationPool.filter(a=>likedIds.includes(String(a.mal_id))).slice(-10).map(a=><AnimeCard key={a.mal_id} anime={a} entry={watchlist[a.mal_id]} onOpen={()=>setSelected(a)} onAdd={()=>add(a)}/>)}</div></section>}
  {page==='calendar'&&<section className="page-section feature-page"><div className="page-title"><div className="eyebrow">AIRING · LIVE-DATEN</div><h1>Release <span>Radar</span></h1><p>Kommende Folgen und laufende Serien aus den verfügbaren AniList-Daten. Countdown-Zeiten aktualisieren sich automatisch.</p></div><div className="radar-banner"><Timer size={20}/><div><b>Nächste Folgen im Blick</b><p>Termine erscheinen nur, wenn die Datenquelle einen konkreten Release-Zeitpunkt liefert.</p></div></div><div className="anime-grid discover-grid">{[...homeTrending,...homeCatalog].filter((a,i,all)=>(a.nextAiringEpisode?.airingAt||a.status==='RELEASING')&&all.findIndex(x=>String(x.mal_id)===String(a.mal_id))===i).sort((a,b)=>(a.nextAiringEpisode?.airingAt||Infinity)-(b.nextAiringEpisode?.airingAt||Infinity)).map(a=><div className="radar-card" key={a.mal_id}><AnimeCard anime={a} entry={watchlist[a.mal_id]} onOpen={()=>setSelected(a)} onAdd={()=>add(a)}/><div className="radar-countdown">{a.nextAiringEpisode?.airingAt? (a.nextAiringEpisode.airingAt*1000>Date.now()?`Folge ${a.nextAiringEpisode.episode||'?'} · ${formatCountdown(a.nextAiringEpisode.airingAt*1000-clockNow)}`:'Release-Zeitpunkt erreicht'):'Läuft aktuell · kein Countdown verfügbar'}</div></div>)}</div>{!homeTrending.some(a=>a.nextAiringEpisode||a.status==='RELEASING')&&!homeCatalog.some(a=>a.nextAiringEpisode||a.status==='RELEASING')&&<div className="empty"><CalendarDays size={30}/><h3>Gerade keine bestätigten Termine geladen</h3><p>Verbinde dich mit dem Internet und lade die Startseite neu, um aktuelle Airing-Daten zu holen.</p></div>}</section>}
  {page==='franchise'&&<section className="page-section feature-page"><div className="page-title"><div className="eyebrow">WATCH ORDER</div><h1>Franchise <span>Guide</span></h1><p>Praktische Watch-Orders mit Hauptserien, Filmen und Specials. Bei komplexen Reihen ist die empfohlene Reihenfolge eine Orientierung.</p></div>{franchiseGuides.map(guide=><div className="franchise-panel" key={guide.name}><div><div className="eyebrow">REIHENFOLGE</div><h2>{guide.name}</h2><p>{guide.note}</p></div><ol>{guide.items.map((item,i)=><li key={item}><span className="order-number">{String(i+1).padStart(2,'0')}</span><span>{item}</span><button className="secondary" onClick={()=>{setPage('discover');searchAnime(null,item);}}>Suchen</button></li>)}</ol></div>)}</section>}
  {page==='profile'&&<section className="page-section feature-page"><div className="page-title"><div className="eyebrow">DEINE ANIME-IDENTITÄT</div><h1>Dein <span>Profil</span></h1><p>Lokales Profil mit Level, XP, Achievements und deinem persönlichen Jahresrückblick.</p></div><div className="profile-hero"><div className="profile-big-avatar">{profileName.trim().charAt(0).toUpperCase()||'A'}</div><div><input className="profile-name-input" value={profileName} onChange={e=>{setProfileName(e.target.value);try{localStorage.setItem('animevault-profile-name',e.target.value);}catch{}}} aria-label="Profilname"/><p>Level {Math.floor((saved.length*40+likedIds.length*15+watched.length*100)/250)+1} · {saved.length*40+likedIds.length*15+watched.length*100} XP</p><div className="xp-track"><span style={{width:`${((saved.length*40+likedIds.length*15+watched.length*100)%250)/250*100}%`}}/></div></div><button className="primary" onClick={exportProfileLink}><Share2 size={16}/> Profil teilen</button></div><div className="friends-panel"><div><h2>Anime-Freunde</h2><p>Füge geteilte Profil-Snapshots hinzu und vergleiche eure Anime-Reise. Deine privaten Watchlist-Daten werden nicht geteilt.</p></div><div className="friend-add"><input value={friendLink} onChange={e=>setFriendLink(e.target.value)} placeholder="Freundes-Profil-Link einfügen …" aria-label="Profil-Link eines Freundes"/><button className="secondary" onClick={addFriendProfile}>Freund hinzufügen</button></div>{friendProfiles.length>0?<div className="friend-grid">{friendProfiles.map(f=><div className="friend-card" key={f.id}><div className="profile-big-avatar">{String(f.name||'A').trim().charAt(0).toUpperCase()}</div><div><b>{f.name}</b><small>{f.completed||0} abgeschlossen · {f.likes||0} Likes</small><span>{(f.favorites||[]).slice(0,2).map(x=>x.title).join(' · ')||'Noch keine Favoriten geteilt'}</span></div><button className="danger-button" onClick={()=>setFriendProfiles(old=>old.filter(x=>x.id!==f.id))}>Entfernen</button></div>)}</div>:<p className="friends-empty">Noch keine Freunde hinzugefügt. Bitte einen Profil-Link über „Profil teilen“ austauschen.</p>}</div><div className="stats-grid stats-large"><Stat icon={<Check/>} label="Abgeschlossen" value={watched.length} foot="Anime fertig geschaut"/><Stat icon={<Heart/>} label="Likes" value={likedIds.length} foot="Dein Geschmack"/><Stat icon={<Clock3/>} label="Geschätzte Watchtime" value={`${Math.round(saved.reduce((sum,x)=>sum+((x.status==='Gesehen'?(x.anime.episodes||0):(x.progress||0))*24),0)/60)} h`} foot="Bei ca. 24 Minuten pro Folge"/><Stat icon={<Trophy/>} label="Level" value={Math.floor((saved.length*40+likedIds.length*15+watched.length*100)/250)+1} foot="XP aus deiner Sammlung"/></div><h2 className="subhead">Achievements</h2><div className="achievement-grid">{achievementList.map(a=>{const unlocked=a.test({saved,watched,watching,likedIds,dislikedIds});return <div className={`achievement ${unlocked?'unlocked':''}`} key={a.id}><div className="achievement-icon">{unlocked?'🏆':'🔒'}</div><div><b>{a.name}</b><p>{a.description}</p></div><span>{unlocked?'Freigeschaltet':'Gesperrt'}</span></div>;})}</div><div className="year-recap"><div className="eyebrow">{currentYear} · DEIN RECAP</div><h2>Dein Anime-Jahr in Zahlen</h2><p>Du hast {completedThisYear.length} Anime in {currentYear} als abgeschlossen markiert, insgesamt {watched.length} abgeschlossen, {likedIds.length} Titel gelikt und {saved.length} Anime in deiner Sammlung. Deine meistgesehenen Genres: {Object.entries(tasteGenres).filter(([,v])=>v>0).sort((a,b)=>b[1]-a[1]).slice(0,3).map(([g])=>g).join(', ')||'noch im Aufbau'}.</p><button className="secondary" onClick={exportProfileLink}><Share2 size={15}/> Recap teilen</button></div></section>}
  {page==='community'&&<section className="page-section feature-page"><div className="page-title"><div className="eyebrow">DEINE LISTEN · DEIN SHARE-LINK</div><h1>Anime <span>Community</span></h1><p>Erstelle thematische Listen, bewerte Anime und teile dein Profil. Listen und Bewertungen bleiben auf diesem Gerät; geteilte Links enthalten eine kompakte Profil-Zusammenfassung.</p></div><div className="community-actions"><button className="primary" onClick={createCustomList}><Plus size={16}/> Neue Liste erstellen</button><button className="secondary" onClick={exportProfileLink}><Share2 size={16}/> Profil-Link kopieren</button></div>{customLists.length===0?<div className="empty"><ListChecks size={30}/><h3>Noch keine eigenen Listen</h3><p>Erstelle z. B. „Top 10“, „Anime für später“ oder „Must Watch“.</p></div>:customLists.map(list=><div className="custom-list-panel" key={list.id}><div className="section-heading"><div><h2>{list.name}</h2><p>{list.ids.length} Anime in dieser Liste</p></div><button className="secondary" onClick={()=>{const data={name:list.name,items:list.ids.map(id=>allRecommendationPool.find(a=>String(a.mal_id)===id)?.title_english||allRecommendationPool.find(a=>String(a.mal_id)===id)?.title||id)};const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`animevault-${list.name.toLowerCase().replace(/[^a-z0-9]+/g,'-')}.json`;a.click();URL.revokeObjectURL(url);notify('Liste exportiert');}}><Download size={15}/> Export</button></div><div className="custom-list-titles">{list.ids.map(id=><span key={id}>{allRecommendationPool.find(a=>String(a.mal_id)===id)?.title_english||allRecommendationPool.find(a=>String(a.mal_id)===id)?.title||id}<button onClick={()=>toggleCustomList(list.id,id)} aria-label="Aus Liste entfernen">×</button></span>)}</div><div className="add-to-custom-list"><select aria-label={`Anime zu ${list.name} hinzufügen`} onChange={e=>{if(e.target.value)toggleCustomList(list.id,e.target.value);e.target.value='';}} defaultValue=""><option value="">Anime hinzufügen …</option>{allRecommendationPool.filter(a=>!list.ids.includes(String(a.mal_id))).map(a=><option key={a.mal_id} value={a.mal_id}>{a.title_english||a.title}</option>)}</select><button className="danger-button" onClick={()=>{if(confirm(`Liste „${list.name}“ löschen?`))setCustomLists(old=>old.filter(x=>x.id!==list.id));}}>Liste löschen</button></div></div>)}<h2 className="subhead">Deine Bewertungen</h2><div className="rating-list">{saved.map(item=><div className="rating-row" key={item.anime.mal_id}><AnimeImage anime={item.anime} alt=""/><div><b>{item.anime.title_english||item.anime.title}</b><small>Deine Bewertung</small></div><div className="rating-stars">{[1,2,3,4,5].map(n=><button key={n} className={n<=(ratings[item.anime.mal_id]||0)?'rated':''} onClick={()=>setRating(item.anime,n)} aria-label={`${n} von 5 Sternen`}>★</button>)}</div></div>)}</div></section>}
  {page==='stats'&&<section className="page-section"><div className="page-title"><div className="eyebrow">DEIN ANIME-PROFIL</div><h1>Deine <span>Statistiken</span></h1><p>Schau dir an, wie deine Anime-Reise gerade aussieht.</p></div><div className="stats-grid stats-large"><Stat icon={<Bookmark/>} label="Gesamt gespeichert" value={saved.length} foot="Alle Anime in deiner Liste"/><Stat icon={<Play/>} label="In Arbeit" value={watching.length} foot="Anime, die du gerade schaust"/><Stat icon={<Check/>} label="Abgeschlossen" value={watched.length} foot="Fertig geschaut"/><Stat icon={<Clock3/>} label="Auf der Watchlist" value={planned.length} foot="Für später vorgemerkt"/></div><div className="stats-grid stats-large"><Stat icon={<Clock3/>} label="Geschätzte Watchtime" value={`${Math.floor(saved.reduce((sum,x)=>sum+((x.status==='Gesehen'?(x.anime.episodes||0):(x.progress||0))*24),0)/60)} h`} foot="24 Minuten pro Folge; Schätzung"/><Stat icon={<Star/>} label="Eigene Bewertungen" value={Object.keys(ratings).length} foot="Bewertungen abgegeben"/><Stat icon={<Heart/>} label="Lieblingsgenres" value={Object.keys(tasteGenres).filter(g=>tasteGenres[g]>0).length} foot="Genres aus deinem Geschmack"/><Stat icon={<Flame/>} label="Likes" value={likedIds.length} foot="Aus dem Swipe-Modus"/></div><div className="genre-breakdown"><h2>Deine Genre-Vorlieben</h2>{Object.entries(tasteGenres).filter(([,v])=>v>0).sort((a,b)=>b[1]-a[1]).slice(0,6).map(([name,value])=><div className="genre-bar-row" key={name}><span>{name}</span><div className="progress"><div style={{width:`${Math.max(5,value/Math.max(1,...Object.values(tasteGenres))*100)}%`}}/></div><b>{value}</b></div>)}{!Object.values(tasteGenres).some(v=>v>0)&&<p>Like oder bewerte Anime, damit deine persönlichen Genre-Vorlieben sichtbar werden.</p>}</div><div className="progress-panel"><h2>Dein Fortschritt</h2><p>So verteilen sich deine gespeicherten Anime.</p>{[['Gesehen',watched.length,'#9a7bff'],['Schaue ich',watching.length,'#6c9cff'],['Geplant',planned.length,'#d18bff']].map(([name,val,color])=><div className="stat-bar-row" key={name}><div><span>{name}</span><b>{val}</b></div><div className="progress"><div style={{width:`${saved.length?val/saved.length*100:0}%`,background:color}}/></div></div>)}</div></section>}
  {page==='settings'&&<section className="page-section"><div className="page-title"><div className="eyebrow">DEIN ACCOUNT</div><h1>Deine <span>Einstellungen</span></h1><p>Deine Sammlung sichern, Geräte synchronisieren und AnimeVault anpassen.</p></div><div className="settings-panel"><div className="setting-row"><div className="setting-symbol"><Sparkles/></div><div><b>AnimeVault</b><p>Dein persönlicher Anime-Tracker mit Cinematic-Design, intelligenteren Empfehlungen, erweiterter Suche und Statistiken.</p></div><span className="version">v3.0</span></div><div className="setting-row"><div className="setting-symbol"><Smartphone/></div><div><b>App-Modus & Offline</b><p>Im veröffentlichten Build installierbar. Watchlist, Likes und Bewertungen bleiben lokal; Live-Daten brauchen Internet.</p></div><span className="version">PWA</span></div><div className="setting-row"><div className="setting-symbol"><ExternalLink/></div><div><b>Anime-Daten & Live-Trends</b><p>AniList liefert Trendtitel und Katalogdaten. Streaming- und Synchro-Verfügbarkeit muss extern geprüft werden.</p></div><a href="https://anilist.co/" target="_blank" rel="noreferrer">AniList ↗</a></div><div className="setting-row"><div className="setting-symbol"><Bookmark/></div><div><b>Lokales Backup</b><p>Exportiere oder importiere deine Watchlist-Datei. Für den Gerätewechsel kannst du alternativ die Cloud-Synchronisierung unten einrichten.</p><div className="backup-actions"><button className="secondary" onClick={exportWatchlist}><Download size={15}/> Backup exportieren</button><label className="secondary file-import"><Upload size={15}/> Backup importieren<input type="file" accept="application/json,.json" onChange={importWatchlist}/></label></div></div><button className="danger-button" onClick={()=>{if(confirm('Wirklich deine gesamte Anime-Liste löschen?')){setWatchlist({});notify('Liste gelöscht');}}}>Liste löschen</button></div></div><div className="cloud-panel"><div className="cloud-panel-head"><div className="setting-symbol"><Share2/></div><div><h2>Cloud-Synchronisierung</h2><p>Mit deinem eigenen Supabase-Projekt kannst du dieselbe Sammlung auf mehreren Geräten nutzen. Deine Cloud-Daten sind durch dein Konto geschützt.</p></div><span className="version">{cloudSession?'Verbunden':'Optional'}</span></div><div className="cloud-fields"><label>Supabase Project URL<input value={cloudUrl} onChange={e=>setCloudUrl(e.target.value)} placeholder="https://deinprojekt.supabase.co" autoComplete="url"/></label><label>Supabase anon / publishable key<input value={cloudKey} onChange={e=>setCloudKey(e.target.value)} placeholder="eyJ... oder sb_publishable_..." autoComplete="off"/></label><label>E-Mail<input type="email" value={cloudEmail} onChange={e=>setCloudEmail(e.target.value)} placeholder="du@example.com" autoComplete="email"/></label><label>Passwort<input type="password" value={cloudPassword} onChange={e=>setCloudPassword(e.target.value)} placeholder="Mindestens 6 Zeichen" autoComplete="current-password"/></label></div><div className="cloud-actions">{cloudSession?<><span className="cloud-account">Angemeldet: {cloudSession.user?.email||'Cloud-Konto'}</span><button className="secondary" disabled={cloudBusy} onClick={()=>cloudSync('upload')}><Upload size={15}/> Cloud hochladen</button><button className="secondary" disabled={cloudBusy} onClick={()=>cloudSync('download')}><Download size={15}/> Cloud wiederherstellen</button><button className="danger-button" onClick={cloudLogout}>Abmelden</button></>:<><button className="primary" disabled={cloudBusy||!cloudEmail.trim()||cloudPassword.length<6} onClick={()=>cloudAuth('signin')}>{cloudBusy?'Bitte warten…':'Anmelden'}</button><button className="secondary" disabled={cloudBusy||!cloudEmail.trim()||cloudPassword.length<6} onClick={()=>cloudAuth('signup')}>Konto erstellen</button></>}</div>{cloudMessage&&<div className="cloud-message" role="status">{cloudMessage}</div>}<details className="cloud-help"><summary>Cloud einmalig einrichten (Supabase)</summary><ol><li>Erstelle ein Projekt auf <a href="https://supabase.com/" target="_blank" rel="noreferrer">supabase.com</a>.</li><li>Trage Project URL und den öffentlichen anon/publishable Key oben ein. Verwende niemals den service_role-Key im Browser.</li><li>Öffne im Supabase SQL Editor und führe das SQL aus der Datei <code>SUPABASE-CLOUD-SYNC.sql</code> aus, die im Projektordner liegt.</li><li>Erstelle ein Konto mit deiner E-Mail und demselben Passwort auf jedem Gerät, melde dich an und wähle „Cloud hochladen“ bzw. „Cloud wiederherstellen“.</li></ol><p>Cloud-Sync ist optional und benötigt Internet sowie ein eigenes Supabase-Projekt. Ohne Einrichtung bleibt AnimeVault vollständig lokal nutzbar.</p></details></div></section>}
  <footer><div className="footer-brand"><Sparkles size={16}/> Anime<span className="accent">Vault</span></div><span>Für Anime-Fans gemacht <span className="pink">♥</span></span><span className="footer-note">Anime-Daten: AniList & Jikan · v3.0</span></footer></main>
  {selected&&<div className="modal-backdrop" onClick={()=>setSelected(null)}><div className="detail-modal" onClick={e=>e.stopPropagation()}><button className="modal-close" onClick={()=>setSelected(null)}><X/></button><AnimeImage anime={selected} className="detail-cover" alt="" loading="eager"/><div className="detail-body"><div className="eyebrow">ANIME-DETAILS</div><h2>{selected.title_english||selected.title}</h2><div className="detail-meta"><span><Star size={14} fill="currentColor"/> {selected.score||'—'}</span><span>{selected.year||selected.aired?.prop?.from?.year||'—'}</span><span>{selected.episodes||'?'} Folgen</span></div><div className="detail-genres">{(selected.genres||[]).map(g=><span key={g.name}>{g.name}</span>)}</div><p>{selected.synopsis||'Für diesen Anime ist momentan keine Beschreibung verfügbar.'}</p><div className="watch-platforms"><h3><Play size={16}/> Wo kann ich das schauen?</h3><p>Die Verfügbarkeit hängt vom Land und vom Abo ab. Öffne eine Plattform-Suche, um aktuelle Angebote für diesen Anime zu prüfen.</p><div className="platform-links"><a href={`https://www.justwatch.com/de/suche?q=${encodeURIComponent(selected.title_english||selected.title)}`} target="_blank" rel="noreferrer">JustWatch Deutschland <ExternalLink size={13}/></a><a href={`https://www.crunchyroll.com/search?q=${encodeURIComponent(selected.title_english||selected.title)}`} target="_blank" rel="noreferrer">Crunchyroll <ExternalLink size={13}/></a><a href={`https://www.netflix.com/search?q=${encodeURIComponent(selected.title_english||selected.title)}`} target="_blank" rel="noreferrer">Netflix <ExternalLink size={13}/></a><a href={`https://www.primevideo.com/search/ref=atv_nb_sr?phrase=${encodeURIComponent(selected.title_english||selected.title)}`} target="_blank" rel="noreferrer">Prime Video <ExternalLink size={13}/></a><a href={`https://www.disneyplus.com/search?q=${encodeURIComponent(selected.title_english||selected.title)}`} target="_blank" rel="noreferrer">Disney+ <ExternalLink size={13}/></a></div></div><div className="watch-platforms dub-platforms"><h3><Sparkles size={16}/> Synchronisationen & Sprachen</h3><div className="dub-status-list"><span className="dub-chip original"><Check size={13}/> Japanisch · Originalton</span>{knownGermanDubs.has((selected.title_english||selected.title||'').toLowerCase().replace(/[^a-z0-9]/g,''))?<span className="dub-chip likely"><Check size={13}/> Deutsche Synchro: bekannt</span>:<span className="dub-chip unknown"><Clock3 size={13}/> Deutsche Synchro: bitte prüfen</span>}<span className="dub-chip unknown">Englische Synchro: Titel prüfen</span></div><p>Hinweis: Das ist ein Orientierungshinweis, keine Garantie für jede Staffel oder Plattform. Die Anime-Datenbanken liefern keine vollständigen, verlässlichen Audio-Sprachen. Die Links öffnen aktuelle Suchergebnisse.</p><div className="platform-links"><a href={`https://www.google.com/search?q=${encodeURIComponent('"'+(selected.title_english||selected.title)+'" deutsche Synchronisation')}`} target="_blank" rel="noreferrer">Deutsch / Ger Dub prüfen <ExternalLink size={13}/></a><a href={`https://www.google.com/search?q=${encodeURIComponent('"'+(selected.title_english||selected.title)+'" English dub cast')}`} target="_blank" rel="noreferrer">Englisch / Eng Dub prüfen <ExternalLink size={13}/></a><a href={`https://www.google.com/search?q=${encodeURIComponent('"'+(selected.title_english||selected.title)+'" Audio languages German Japanese English')}`} target="_blank" rel="noreferrer">Alle Audio-Sprachen prüfen <ExternalLink size={13}/></a></div></div><div className="watch-platforms user-rating-panel"><h3><Star size={16}/> Deine Bewertung</h3><div className="rating-stars detail-stars">{[1,2,3,4,5].map(n=><button key={n} className={n<=(ratings[selected.mal_id]||0)?'rated':''} onClick={()=>setRating(selected,n)} aria-label={`${n} von 5 Sternen`}>★</button>)}</div></div>{relatedAnime.length>0&&<div className="watch-platforms related-platforms"><h3><Compass size={16}/> Reihenfolge & verbundene Anime</h3><p>Fortsetzungen, Vorgänger und weitere Einträge aus derselben Reihe.</p><div className="related-list">{relatedAnime.map((item,i)=><button key={`${item.anilist_id||item.mal_id}-${i}`} onClick={()=>setSelected(item)}><span className="related-type">{{PREQUEL:'Vorgänger',SEQUEL:'Fortsetzung',SIDE_STORY:'Nebenstory',PARENT:'Hauptreihe',SUMMARY:'Zusammenfassung'}[item.relationType]||'Verknüpft'}</span><span>{item.title_english||item.title}</span><span className="related-year">{item.year||'—'}</span></button>)}</div></div>}<div className="modal-actions"><button className="primary" onClick={()=>{add(selected);setSelected(null);}}><Plus size={17}/> Zur Liste hinzufügen</button><button className="secondary" onClick={()=>{add(selected,'Gesehen');setSelected(null);}}><Check size={17}/> Gesehen</button></div></div></div></div>}
  {toast&&<div className="toast"><Check size={16}/>{toast}</div>}</div>
}

function formatCountdown(ms){if(ms<=0)return 'jetzt';const total=Math.floor(ms/1000);const days=Math.floor(total/86400);const hours=Math.floor((total%86400)/3600);const mins=Math.floor((total%3600)/60);return days?`${days} T ${hours} Std.`:hours?`${hours} Std. ${mins} Min.`:`${mins} Min.`;}
const franchiseGuides=[
 {name:'Attack on Titan',note:'Für den ersten Durchlauf ist die Veröffentlichungsreihenfolge am einfachsten.',items:['Attack on Titan – Staffel 1','Attack on Titan – Staffel 2','Attack on Titan – Staffel 3','Attack on Titan – Staffel 3 Part 2','Attack on Titan: The Final Season','The Final Chapters – Special 1','The Final Chapters – Special 2']},
 {name:'Fullmetal Alchemist',note:'Brotherhood ist die eigenständige, vollständige Manga-Adaption. Der Film ist optional.',items:['Fullmetal Alchemist: Brotherhood','The Sacred Star of Milos (optional)']},
 {name:'Demon Slayer',note:'Staffeln und Kinofilm in der üblichen Veröffentlichungsreihenfolge.',items:['Tanjiro Kamado, Unwavering Resolve Arc','Mugen Train (Film oder TV-Version – eine Variante reicht)','Entertainment District Arc','Swordsmith Village Arc','Hashira Training Arc','Infinity Castle (Filmreihe – Reihenfolge nach Veröffentlichung)']},
 {name:'Dragon Ball',note:'Eine einfache Einsteiger-Reihenfolge; Filme sind je nach Kontinuität optional.',items:['Dragon Ball','Dragon Ball Z oder Dragon Ball Z Kai','Dragon Ball Super','Dragon Ball Super: Broly','Dragon Ball Super: Super Hero']},
 {name:'Naruto',note:'Die Filme sind größtenteils optional; The Last gehört nach Naruto Shippuden.',items:['Naruto','Naruto Shippuden','The Last: Naruto the Movie','Boruto: Naruto Next Generations']},
 {name:'Fate (Einsteiger-Tipp)',note:'Die Fate-Reihe hat alternative Adaptionen und mehrere Zeitlinien. Diese Reihenfolge ist ein gängiger Einstieg.',items:['Fate/stay night: Unlimited Blade Works','Fate/stay night: Heaven’s Feel I','Fate/stay night: Heaven’s Feel II','Fate/stay night: Heaven’s Feel III','Fate/Zero (Prequel)']}
];
const achievementList=[
 {id:'first',name:'Erster Schritt',description:'Speichere deinen ersten Anime.',test:({saved})=>saved.length>=1},
 {id:'five',name:'Binge-Starter',description:'Speichere 5 Anime.',test:({saved})=>saved.length>=5},
 {id:'done1',name:'Abspann gesehen',description:'Schließe einen Anime ab.',test:({watched})=>watched.length>=1},
 {id:'done10',name:'Anime-Marathon',description:'Schließe 10 Anime ab.',test:({watched})=>watched.length>=10},
 {id:'likes',name:'Geschmack entwickelt',description:'Vergib 5 Likes im Swipe-Modus.',test:({likedIds})=>likedIds.length>=5},
 {id:'variety',name:'Genre-Hopper',description:'Speichere 5 Anime und entdecke neue Genres.',test:({saved})=>new Set(saved.flatMap(x=>(x.anime.genres||[]).map(g=>g.name))).size>=5},
 {id:'ongoing',name:'Mittendrin',description:'Schau mindestens einen Anime aktiv.',test:({watching})=>watching.length>=1},
 {id:'explorer',name:'Mut zum Neuen',description:'Überspringe im Swipe-Modus 10 Titel.',test:({dislikedIds})=>dislikedIds.length>=10}
];

function Stat({icon,label,value,foot}){return <div className="stat-card"><div className="stat-top"><div className="stat-icon">{icon}</div><span className="stat-arrow">↗</span></div><div className="stat-value">{value}</div><div className="stat-label">{label}</div><div className="stat-foot">{foot}</div></div>}
function AnimeCard({anime,entry,onOpen,onAdd}){const img=anime.images?.jpg?.large_image_url||anime.images?.jpg?.image_url;return <article className="anime-card"><button className="cover-button" onClick={onOpen} aria-label={`${anime.title} Details öffnen`}><AnimeImage anime={anime} alt={anime.title} loading="lazy"/><span className="cover-overlay"><span className="play-circle"><Play size={19} fill="currentColor"/></span><span>Details ansehen</span></span>{anime.score&&<span className="score-pill"><Star size={12} fill="currentColor"/>{anime.score}</span>}</button><div className="card-content"><button className="card-title" onClick={onOpen}>{anime.title_english||anime.title}</button><div className="card-meta"><span>{anime.year||anime.aired?.prop?.from?.year||'Anime'}</span><span>•</span><span>{anime.episodes||'?'} Folgen</span></div>{anime.nextAiringEpisode?.airingAt&&<span className="airing-info">Folge {anime.nextAiringEpisode.episode||'?'} · {new Date(anime.nextAiringEpisode.airingAt*1000).toLocaleDateString('de-DE',{day:'2-digit',month:'2-digit',year:'numeric'})}</span>}<div className="card-bottom"><div className="genre-list">{(anime.genres||[]).slice(0,2).map(g=><span key={g.name}>{g.name}</span>)}</div><button className={`add-button ${entry?'saved':''}`} title={entry?`Status: ${entry.status}`:'Zur Liste hinzufügen'} onClick={()=>!entry&&onAdd()}>{entry?<Check size={16}/>:<Plus size={17}/>}</button></div>{entry&&<div className="saved-label">{entry.status}</div>}</div></article>}
export default App;
