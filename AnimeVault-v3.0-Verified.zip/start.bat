@echo off
cd /d "%~dp0"
title AnimeVault
if not exist "node_modules" (
  echo Installiere benoetigte Dateien beim ersten Start...
  call npm install
  if errorlevel 1 (echo Installation fehlgeschlagen. Ist Node.js installiert? & pause & exit /b 1)
)
start "AnimeVault im Browser" http://localhost:5173
call npm run dev -- --host 127.0.0.1
pause
